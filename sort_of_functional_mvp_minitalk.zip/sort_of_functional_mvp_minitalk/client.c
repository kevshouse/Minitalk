#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include "libft/includes/libft.h"

static void send_char(int pid, unsigned char c)
{
	int		bit;
	
	bit = 0;
	while (bit < 8)
	{
		//LSB first approach
		kill(pid, (c >> bit & 1) ? SIGUSR1: SIGUSR2);
		bit++;
		usleep(150); // signal pacing
	}
}

int main (int argc, char **argv)
{
	int		pid;
	char	*str;
	
	if (argc != 3) // Arg validation
	{
		ft_printf("Usage: %s <PID> <string>\n", argv[0]);
		return (1);
	}
	pid = ft_atoi(argv[1]);
	if (kill(ft_atoi(argv[1]), 0) == -1)
	{
		ft_printf("Error: Invalid PID or perms\n"); 
		return (1);
	}
	str = argv[2];
	while (*str){
		send_char(pid, *str++);
		//printf(".");
		}
	send_char(pid, '\0');
	return (0);
}
