#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include "libft/includes/libft.h"

static void handle_signal(int sig, siginfo_t *info, void *context)
{
	static unsigned char	current_char = 0;
	static int		bit_index = 0;
	(void)info;
	(void)context;
		
		
// |= eqautes to a = a | b: (bitwise OR assigned back to a)
	current_char |= (sig == SIGUSR1) << bit_index;
	bit_index++;
	//printf("bit_index = %d\n", bit_index);
	if (bit_index == 8) //Complete char RX
	{
		//printf("We got 8 bits!");
		//printf("%c", current_char);
		write(1, &current_char, 1);
		bit_index = 0;
		current_char = 0;
	}
}

int main(void)
{
	struct sigaction sa;	
	
	printf("Server PID: %d\n", getpid());
	sa.sa_sigaction = handle_signal;
	sa.sa_flags = SA_SIGINFO | SA_RESTART;
	// Block sigs during handler execution
	sigemptyset(&sa.sa_mask);
	sigaddset(&sa.sa_mask, SIGUSR1);
	sigaddset(&sa.sa_mask, SIGUSR2);
	
	sigaction(SIGUSR1, &sa, NULL);
	sigaction(SIGUSR2, &sa, NULL);
	while (1){
		//printf("^");
		pause();// gets interupted by the OS when signal arrives.
		}
	return (0);
}

