f/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   server.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/07 16:11:39 by keanders          #+#    #+#             */
/*   Updated: 2025/04/08 12:55:00 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libft/includes/libft.h"
#include "minitalk.h"
#include <signal.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#define MAX_CLIENTS 10
#define INACTIVITY_TIMEOUT 10 // Seconds

static t_client	g_clients[MAX_CLIENTS];

// Find or create client entry with cleanup
static t_client	*get_client(int pid)
{
	int		i;
	time_t	current_time;

	i = 0;
	current_time = time(NULL);
	// First pass: Check existing client or empty slot
	while (i < MAX_CLIENTS)
	{
		if (g_clients[i].pid == pid)
			return (&g_clients[i]);
		if (g_clients[i].pid == 0)
		{
			ft_memset(&g_clients[i], 0, sizeof(t_client));
			g_clients[i].pid = pid;
			g_clients[i].last_active = current_time;
			return (&g_clients[i]);
		}
		i++;
	}
	// Second pass: Clean inactive clients
	i = 0;
	while (i < MAX_CLIENTS)
	{
		if (g_clients[i].pid != 0 && difftime(current_time,
				g_clients[i].last_active) > INACTIVITY_TIMEOUT)
		{
			ft_memset(&g_clients[i], 0, sizeof(t_client));
			g_clients[i].pid = pid;
			g_clients[i].last_active = current_time;
			return (&g_clients[i]);
		}
		i++;
	}
	return (NULL); // All slots full and active
}

// Detect UTF-8 character length
static void	detect_utf8_length(t_client *c)
{
	if ((c->buffer[0] & 0b11110000) == 0b11110000)
		c->expected_bytes = 4;
	else if ((c->buffer[0] & 0b11100000) == 0b11100000)
		c->expected_bytes = 3;
	else if ((c->buffer[0] & 0b11000000) == 0b11000000)
		c->expected_bytes = 2;
	else
		c->expected_bytes = 1;
}

// Signal handler
void	handle_signal(int sig, siginfo_t *info, void *context)
{
	t_client	*client;
	int			bit_value;

	(void)context;
	client = get_client(info->si_pid);
	if (!client)
		return ;
	client->last_active = time(NULL);
	bit_value = (sig == SIGUSR1) ? 0 : 1;
	client->buffer[client->byte_count] |= (bit_value << (7
				- client->bit_count));
	client->bit_count++;
	if (client->bit_count == 8)
	{
		client->bit_count = 0;
		if (client->byte_count == 0)
			detect_utf8_length(client);
		if (++client->byte_count == client->expected_bytes)
		{
			write(1, client->buffer, client->expected_bytes);
			// ✅ Proper buffer reset:
			ft_memset(client->buffer, 0, sizeof(client->buffer));
			client->byte_count = 0;
			client->expected_bytes = 0;
		}
	}
	kill(info->si_pid, SIGUSR1);
}

int	main(void)
{
	struct sigaction	sa;

	ft_printf("Server PID: %d\n", getpid());
	ft_memset(&sa, 0, sizeof(sa));
	sa.sa_sigaction = handle_signal;
	sa.sa_flags = SA_SIGINFO;
	sigaction(SIGUSR1, &sa, NULL);
	sigaction(SIGUSR2, &sa, NULL);
	while (1)
		pause();
	return (0);
}
