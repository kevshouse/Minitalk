#!/bin/bash

# Configuration
test_file="test_file.txt"            # Hardcoded test file
num_clients=2                         # Number of clients for the bonus phase
client_delay=0.1                      # Delay in seconds between client spawning

# Function to start the server and capture its PID
start_server() {
    local output_file="server_out_cl${1}"  # Unique output file for each client
    ./server > "$output_file" 2>&1 &  # Redirect stdout and stderr to a file
    pid=$!  # Capture the PID of the server
    sleep 1  # Wait for the server to start
    echo "Server started with PID: $pid"
    echo "$output_file"  # Return the output file name
}

# Function to stop the server
stop_server() {
    kill "$pid"
    echo "Server with PID $pid stopped."
}

# Function to run clients
run_clients() {
    for ((i = 0; i < num_clients; i++)); do
        echo "Starting client $((i + 1))..."
        output_file=$(start_server "$i")  # Start server for each client and get the output file name
        ./client "$pid" "$(cat "$test_file")" &
        sleep "$client_delay"  # Delay between client spawning
        wait  # Wait for the client to finish
        compare_input_output "$output_file"  # Compare input with the current client's output
    done
}

# Function to compare input and output
compare_input_output() {
    local output_file=$1
    echo "Comparing input and output for $output_file..."
    if diff "$test_file" "$output_file" > /dev/null; then
        echo "Input and output match for $output_file."
    else
        echo "Input and output differ for $output_file:"
        diff "$test_file" "$output_file"
    fi
}

# Main script execution
run_clients
stop_server
