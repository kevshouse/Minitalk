#!/bin/bash

# Function to generate a random colorful character
random_colorful_char() {
    # Define a range of colorful square and circle characters
    local colorful_chars=(
        "🔴" "🟠" "🟡" "🟢" "🔵" "🟣" "🟤" "⚫" "⚪" "🟡" "🟠" "🟣" "🟦" "🟩" "🟧" "🟥"
        "⬛" "⬜" "🔲" "🔳" "🔵" "🔴" "🟡" "🟢" "🟣" "🟤" "🟠" "🟩" "🟦" "🟧" "🟥"
    )

    # Select a random index from the colorful_chars array
    local index=$((RANDOM % ${#colorful_chars[@]}))
    echo "${colorful_chars[$index]}"
}

# Function to create a colorful grid pattern
create_colorful_grid() {
    local rows=$1
    local cols=$2

    # Print the grid
    for ((i = 0; i < rows; i++)); do
        for ((j = 0; j < cols; j++)); do
            # Print a random colorful character
            printf "%s " "$(random_colorful_char)"
        done
        echo  # New line after each row
    done
}

# Main script execution
# Set the desired grid size
rows=16  # Number of rows
cols=16  # Number of columns

create_colorful_grid "$rows" "$cols"