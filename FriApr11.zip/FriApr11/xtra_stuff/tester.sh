#!/bin/bash

# Configuration
test_file="test-dir/test_file.txt"  # Hardcoded test file
output_file="server_output.txt"      # File where server output will be captured
num_clients=2                         # Number of clients for the bonus phase
client_delay=0.1                      # Delay in seconds between client spawning

# Function to start the server and capture its PID
start_server() {
    ./server > server_output.txt 2>&1 &  # Redirect stdout and stderr to a file
    pid=$!  # Capture the PID of the server
    sleep 1  # Wait for the server to start
    echo "Server started with PID: $pid"
}

# Function to stop the server
stop_server() {
    kill "$pid"
    echo "Server with PID $pid stopped."
}

# Function to run mandatory tests
run_mandatory_tests() {
    start_server

    # Count characters in the input file
    chars_in_file=$(wc -c < "$test_file")

    # Send the file content to the server
    echo "Sending content to server..."
    ./client "$pid" "$(cat "$test_file")"

    # Wait for the server to finish processing
    wait "$pid"

    # Capture the server output
    cat server_output.txt > "$output_file"

    # Count characters in the server output
    chars_in_output=$(wc -c < "$output_file")

    # Compare character counts
    if [ "$chars_in_output" -eq "$chars_in_file" ]; then
        echo "Mandatory tests passed: Output matches input character count."
    else
        echo "Mandatory tests failed: Output does not match input character count."
    fi

    stop_server
}

# Function to run bonus tests
run_bonus_tests() {
    start_server

    # Initialize total character count
    total_input_chars=0

    # Count characters in the input file
    chars_in_file=$(wc -c < "$test_file")
    total_input_chars=$((total_input_chars + chars_in_file))

    # Queue the tests for each client
    for ((i = 0; i < num_clients; i++)); do
        echo "Starting client $((i + 1))..."
        # Send the file content to the server
        ./client "$pid" "$(cat "$test_file")" &
        sleep "$client_delay"  # Delay between client spawning
    done

    # Wait for all clients to finish
    wait

    # Capture the server output
    cat server_output.txt > "$output_file"

    # Count characters in the server output
    chars_in_output=$(wc -c < "$output_file")

    # Compare character counts
    if [ "$chars_in_output" -eq "$total_input_chars" ]; then
        echo "Bonus tests passed: Output matches input character count."
    else
        echo "Bonus tests failed: Output does not match input character count."
    fi

    stop_server
}

# Main script execution
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 [m|b]"
    echo "  m: Run mandatory tests"
    echo "  b: Run bonus tests"
    exit 1
fi

case "$1" in
    m)
        echo "Running mandatory tests..."
        run_mandatory_tests
        ;;
    b)
        echo "Running bonus tests..."
        run_bonus_tests
        ;;
    *)
        echo "Invalid option: $1"
        echo "Usage: $0 [m|b]"
        exit 1
        ;;
esac
