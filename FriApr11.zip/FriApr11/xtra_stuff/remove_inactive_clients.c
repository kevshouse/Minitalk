// Find/Create client entry
static t_client *get_client(int pid)
{
    for (int i = 0; i < MAX_CLIENTS; i++)
    {
        // Check if the client is already registered
        if (g_clients[i].pid == pid)
        {
            return &g_clients[i]; // Return existing client
        }
        
        // Check for inactive clients (e.g., pid == 0)
        if (g_clients[i].pid == 0)
        {
            ft_memset(&g_clients[i], 0, sizeof(t_client)); // Reset the client structure
            g_clients[i].pid = pid; // Assign new client PID
            return &g_clients[i]; // Return new client
        }
    }

    // Optional: Cleanup logic for inactive clients
    // Here you can implement logic to check for clients that have not sent signals for a while
    // and reset their entries if needed.
void delete_inactive_clients(void){}    

    return (NULL); // Still returns NULL if all slots are filled
}

//What sort of logic do I need checking for clients that have not sent signals for a while?
