/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/12 13:14:53 by keanders          #+#    #+#             */
/*   Updated: 2025/02/22 12:16:48 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H
# pragma once
# include "libft.h"
# include <stdarg.h>


typedef struct s_counter
{
    int    count;
}              t_counter;
int     ft_printf(const char *format, ...);
void    pf_putchar(char c, int *count);
void    pf_putstr(char *str, int *count);
void    pf_putnbr(int n, int *count);
void    pf_puthex(unsigned int n, int uppercase, int *count);
void    pf_putptr(unsigned long ptr, int *count);
void    pf_putunsigned(unsigned int n, int *count);

#endif
