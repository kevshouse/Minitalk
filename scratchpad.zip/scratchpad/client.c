#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>  // Added for printf

void send_bit(int pid, int bit)
{
    if (bit)
        kill(pid, SIGUSR2);
    else
        kill(pid, SIGUSR1);
    usleep(100);
}

void send_byte(int pid, char c)
{
    int i = 7;  // Start from MSB (bit 7)
    while (i >= 0)  // Changed to include bit 0
    {
        int bit = (c >> i) & 1;
        send_bit(pid, bit);
        i--;    
    }
}

int main(int argc, char **argv)
{
    if (argc != 3)  // Moved this check to FIRST
    {
        fprintf(stderr, "Usage: %s <server_pid> <message>\n", argv[0]);
        return 1;
    }

    int server_pid = atoi(argv[1]);
    char *message = argv[2];
    size_t i = 0;  // Initialize counter

    // Send each character
    while (i < strlen(message))
    {
        send_byte(server_pid, message[i]);
        i++;
    }
    
    // Optional: Send null terminator
    send_byte(server_pid, '\0');
    
    return 0;
}

