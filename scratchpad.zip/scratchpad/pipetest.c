#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/select.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>

#define BUFFER_SIZE 1024

typedef struct 
{
    volatile size_t head;
    volatile size_t tail;
    char data[BUFFER_SIZE];
} CircularBuffer;

static CircularBuffer bit_buffer = {0, 0, {0}};
static int signal_pipe[2];

void sig_handler(int sig)
{
    char bit = (sig == SIGUSR1) ? '0' : '1';
    write(signal_pipe[1], &bit, 1);
}

int has_8_bits(const CircularBuffer *buf)
{
    return ((buf->tail - buf->head + BUFFER_SIZE) % BUFFER_SIZE) >= 8;
}

char dequeue_byte(CircularBuffer *buf)
{
    char byte = 0;
    for (int i = 0; i < 8; i++)
    {
        byte = (byte << 1) | (buf->data[buf->head] == '1' ? 1 : 0);
        buf->head = (buf->head + 1) % BUFFER_SIZE;
    }
    return byte;
}

int main(void) {
    // Print server PID
    printf("Server PID: %d\n", getpid());
    fflush(stdout);

    // Create pipe
    if (pipe(signal_pipe))
    {
        perror("pipe");
        return 1;
    }

    // Set non-blocking mode
    fcntl(signal_pipe[0], F_SETFL, O_NONBLOCK);
    fcntl(signal_pipe[1], F_SETFL, O_NONBLOCK);

    // Register signal handlers
    struct sigaction sa = {0};
    sa.sa_handler = sig_handler;
    sigaction(SIGUSR1, &sa, NULL);
    sigaction(SIGUSR2, &sa, NULL);

    fd_set read_fds;
    while (1) {
        FD_ZERO(&read_fds);
        FD_SET(signal_pipe[0], &read_fds);

        // Handle select interruptions
        int select_ret;
        /*do {
            select_ret = select(signal_pipe[0] + 1, &read_fds, NULL, NULL, NULL);
        } while (select_ret == -1 && errno == EINTR);*/
        while (1)
        {
        	select_ret = select(signal_pipe[0] + 1, &read_fds, NULL, NULL,
        		NULL);
        	if (select_ret != -1 || errno != EINTR)
        		break;
        }

        if (select_ret == -1) {
            perror("select");
            return 1;
        }

        if (FD_ISSET(signal_pipe[0], &read_fds)) {
            char bit;
            while (read(signal_pipe[0], &bit, 1) > 0) {
                // Check buffer space
                size_t next_tail = (bit_buffer.tail + 1) % BUFFER_SIZE;
                if (next_tail != bit_buffer.head) {
                    bit_buffer.data[bit_buffer.tail] = bit;
                    bit_buffer.tail = next_tail;
                }
            }
        }

        // Process complete bytes
        while (has_8_bits(&bit_buffer)) {
            char byte = dequeue_byte(&bit_buffer);
            write(1, &byte, 1);
        }
    }

    return 0;
}
