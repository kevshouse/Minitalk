/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_util.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/12 13:50:22 by keanders          #+#    #+#             */
/*   Updated: 2025/02/12 17:51:57 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void    pf_putchar(char c, int *count)
{
	ft_putchar_fd(c, 1);
	(*count)++;
}

void    pf_putstr(char *str, int *count)
{
	if (!str)
		str = "(null)";
	while (*str)
		pf_putchar(*str++, count);
}

void    pf_putnbr(int n, int *count)
{
	if (n == -2147483648)
		pf_putstr("-2147483648", count);
	else 
	{
		if (n < 0)
		{
        		pf_putchar('-', count);
        		n = -n;
        	}
        if (n > 9)
		pf_putnbr(n / 10, count);
	pf_putchar(n % 10 + '0', count);
    }
}

void pf_puthex(unsigned int n, int uppercase, int *count)
{
	char    *base;

	base = "0123456789abcdef";
	if (uppercase)
		base = "0123456789ABCDEF";
	if (n >= 16)
		pf_puthex(n / 16, uppercase, count);
	pf_putchar(base[n % 16], count);
}

void pf_putptr(unsigned long ptr, int *count)
{
	pf_putstr("0x", count);
	pf_puthex(ptr, 0, count);
}

void pf_putunsigned(unsigned int n, int *count)
{
	if (n > 9)
		pf_putunsigned(n / 10, count);
	pf_putchar(n % 10 + '0', count);
}

/*void	func_select(char c, va_list args, int *count)
{
	if (c == '%')
		pf_putchar_fd(c, 1, count);
	else if (c == 'c')
		pf_putchar_fd(va_arg(args, int), 1, count);
	else if (c == 'd' || c == 'i')
		ft_putnbr_fd(va_arg(args, int), 1, count);
	else if (c == 's')
		pf_putstr_fd(va_arg(args, char *), 1, count);
	else if (c == 'x')
		ft_puthex_fd(va_arg(args, int), 1, count);
	else if (c == 'X')
		ft_putchex_fd(va_arg(args, int), 1, count);
	else if (c == 'u')
		ft_putuns_fd(va_arg(args, int), 1, count);
	else if (c == 'p')
		ft_putptr_fd(va_arg(args, void *), 1, count);
}*/
