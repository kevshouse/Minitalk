#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include "libft/includes/libft.h"

static volatile sig_atomic_t g_ack = 0;

static void ack_handler(int sig)
{
	(void)sig;
	g_ack = 1;
}

static void send_char(int pid, unsigned char c)
{
	int		bit;
	
	bit = 0;
	struct sigaction sa;
	
	//init ACK handler
	sa.sa_handler = ack_handler;
	sa.sa_flags = 0;
	sigemptyset(&sa.sa_mask);
	sigaction(SIGUSR1, &sa, NULL);
	
	while (bit < 8)
	{
		g_ack = 0;
		//LSB first approach
		kill(pid, (c >> bit & 1) ? SIGUSR1: SIGUSR2);
		bit++;
		while (!g_ack)
			pause();
	}
}

int main (int argc, char **argv)
{
	int		pid;
	char	*str;
	
	if (argc != 3) // Arg validation
	{
		ft_printf("Usage: %s <PID> <string>\n", argv[0]);
		return (1);
	}
	pid = ft_atoi(argv[1]);
	if (kill(pid, 0) == -1)
	{
		ft_printf("Error: Invalid PID\n"); 
		return (1);
	}
	str = argv[2];
	while (*str){
		send_char(pid, *str++);
		//printf(".");
		}
	send_char(pid, '\0');
	return (0);
}
