#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

// Global variable for tracking received bits
static volatile sig_atomic_t g_received_bit = 0;

void    sig_handler(int sig, siginfo_t *info, void *context)
{
    (void)context;
    // Decode signal to bit value
    g_received_bit = (sig == SIGUSR1) ? 0 : 1;
    
    // Send ACK back to client (using PID from siginfo_t)
    kill(info->si_pid, SIGUSR1);
}

int main(void)
{
    struct sigaction    sa;
    
    // 1. Print Server PID
    printf("Server PID: \033[0;32m%d\033[0m\n", getpid());
    fflush(stdout);  // Ensure PID prints immediately

    // 2. Configure Signal Handling
    sa.sa_sigaction = sig_handler;  // Use advanced handler
    sa.sa_flags = SA_SIGINFO;       // Get sender PID in handler
    sigemptyset(&sa.sa_mask);       // Start with empty signal mask
    
    // Block other signals during handler execution
    sigaddset(&sa.sa_mask, SIGUSR1);
    sigaddset(&sa.sa_mask, SIGUSR2);

    // Register signal handlers
    if (sigaction(SIGUSR1, &sa, NULL) == -1
        || sigaction(SIGUSR2, &sa, NULL) == -1)
    {
        perror("sigaction error");
        exit(EXIT_FAILURE);
    }

    // 3. Main loop to process incoming bits
    while (1)
    {
        pause();  // Wait for signals
        // (In real implementation, process g_received_bit here)
    }
    return (0);
}
