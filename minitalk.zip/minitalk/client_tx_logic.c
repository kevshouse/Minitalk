#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

static volatile sig_atomic_t g_ack_received = 0;

// Signal handler for ACKs from server
void    ack_handler(int sig)
{
    (void)sig;
    g_ack_received = 1;
}

// Send a single bit and wait for ACK
void    send_bit(int pid, int bit)
{
    sigset_t    mask;
    
    // Block SIGUSR1 during transmission
    sigemptyset(&mask);
    sigaddset(&mask, SIGUSR1);
    sigprocmask(SIG_BLOCK, &mask, NULL);

    g_ack_received = 0;
    if (kill(pid, (bit) ? SIGUSR2 : SIGUSR1) == -1)
    {
        write(2, "Error: Invalid PID\n", 19);
        exit(EXIT_FAILURE);
    }

    // Wait for ACK (unblock SIGUSR1 temporarily)
    while (!g_ack_received)
        sigsuspend(&mask);

    sigprocmask(SIG_UNBLOCK, &mask, NULL);
}

// Send entire message character-by-character
void    send_message(int pid, const char *msg)
{
    struct sigaction    sa;
    
    // Configure ACK handler
    sa.sa_handler = &ack_handler;
    sa.sa_flags = 0;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, NULL);

    // Send each character
    while (*msg)
    {
        char c = *msg++;
        for (int i = 0; i < 8; i++)
        {
            int bit = (c >> i) & 1;  // LSB-first transmission
            send_bit(pid, bit);
        }
    }
    
    // Send null terminator
    for (int i = 0; i < 8; i++)
        send_bit(pid, 0);
}
