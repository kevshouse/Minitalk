/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/15 17:24:54 by keanders          #+#    #+#             */
/*   Updated: 2025/04/18 20:14:34 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minitalk.h"
#include "../../inc/libft.h"

int	ft_isspace(int c)
{
	return (c == ' ' || (c >= '\t' && c <= '\r'));
}

static int	handle_sign(const char **str, int *sign)
{
	if (**str == '-' || **str == '+')
	{
		if (**str == '-')
			*sign = -1;
		(*str)++;
	}
	return (1);
}

static int	process_digits(const char **str, int sign, long long *result)
{
	while (ft_isdigit(**str))
	{
		*result = *result * 10 + (**str - '0');
		if ((sign == 1 && *result > INT_MAX) || (sign == -1
				&& *result > (long long)INT_MAX + 1))
			return (-1);
		(*str)++;
	}
	return (1);
}

int	ft_atoi(const char *str)
{
	int			sign;
	long long	result;

	sign = 1;
	result = 0;
	if (!str || !*str)
		return (-1);
	while (ft_isspace(*str))
		str++;
	handle_sign(&str, &sign);
	if (!ft_isdigit(*str))
		return (-1);
	if (process_digits(&str, sign, &result) == -1)
		return (-1);
	if (*str)
		return (-1);
	return ((int)(result * sign));
}
