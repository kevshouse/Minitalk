/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bit_tx.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/17 18:45:55 by keanders          #+#    #+#             */
/*   Updated: 2025/04/18 18:05:21 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/minitalk.h"

volatile sig_atomic_t	g_ack_received = 0;

void	ack_handler(int sig)
{
	(void)sig;
	g_ack_received = 1;
}

void tx_bit(int server_pid, int bit)
{
	if (kill(server_pid, bit ? SIGUSR2 : SIGUSR1) < 0)
	{
		write(STDERR_FILENO, "Error: Sig transmission failed\n", 31);
		exit(EXIT_FAILURE);
    }
	g_ack_received = 0;
	while (!g_ack_received)
        usleep(100);
}

void	tx_char(int server_pid, char c)
{
	int	i;
	int	bit;

	i = 7;
	while (i >= 0)
	{
		bit = (c >> i) & 1;
		tx_bit(server_pid, bit);
		i--;
	}
}
