/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sig_handler.h                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/18 18:00:08 by keanders          #+#    #+#             */
/*   Updated: 2025/04/18 18:00:19 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SIG_HANDLER_H
# define SIG_HANDLER_H
# include "../../inc/minitalk.h"
# include <signal.h>
# include <sys/types.h>

// Signal handler function prototype
void	sig_handler(int sig, siginfo_t *info, void *context);

#endif // SIG_HANDLER_H
