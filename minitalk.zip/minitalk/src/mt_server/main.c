/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/16 12:52:28 by keanders          #+#    #+#             */
/*   Updated: 2025/04/18 17:59:22 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minitalk.h"
#include "sig_handler.h"

int	main(void)
{
	struct sigaction	sa;

	sigemptyset(&sa.sa_mask);
	sa.sa_sigaction = sig_handler;
	sa.sa_flags = SA_SIGINFO | SA_NODEFER;
	if (sigaction(SIGUSR1, &sa, NULL) < 0)
	{
		write(STDERR_FILENO, "Error: SIGUSR1 setup failed\n", 28);
		exit(EXIT_FAILURE);
	}
	if (sigaction(SIGUSR2, &sa, NULL) < 0)
	{
		write(STDERR_FILENO, "Error: SIGUSR2 setup failed\n", 28);
		exit(EXIT_FAILURE);
	}
	write(1, "Server PID: ", 12);
	ft_putpid(getpid());
	write(1, "\n", 1);
	while (1)
		pause();
	return (0);
}
