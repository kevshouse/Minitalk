/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sig_handler.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/18 17:51:43 by keanders          #+#    #+#             */
/*   Updated: 2025/04/18 17:51:58 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minitalk.h"
#include "sig_handler.h"

void	sig_handler(int sig, siginfo_t *info, void *context)
{
	static pid_t	client_pid = 0;
	static int		bit_count = 0;
	static char		c = 0;

	(void)context;
	if (client_pid == 0)
		client_pid = info->si_pid;
	if (client_pid != info->si_pid)
		return ;
	c |= (sig == MY_SIG_BIT1) << (7 - bit_count);
	bit_count++;
	if (bit_count == 8)
	{
		if (c)
			write(1, &c, 1);
		else
			write(1, "\n", 1);
		bit_count = 0;
		c = 0;
	}
	usleep(50);
	kill(client_pid, MY_SIG_BIT0);
}
