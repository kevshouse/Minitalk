#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#define BUFFER_SIZE 1024

// Shared state (static for signal safety)
static char     buffer[BUFFER_SIZE];
static int      buf_idx = 0;
static char     current_char = 0;
static int      bit_idx = 0;

void    sig_handler(int sig, siginfo_t *info, void *context)
{
    (void)context;

    // 1. Decode signal to bit (SIGUSR1=0, SIGUSR2=1)
    current_char |= (sig == SIGUSR2) << bit_idx;
    bit_idx++;

    // 2. Full byte received?
    if (bit_idx == 8)
    {
        if (current_char == '\0' || buf_idx == BUFFER_SIZE - 1)
        {
            buffer[buf_idx] = '\0';
            write(1, buffer, buf_idx);
            write(1, "\n", 1);
            buf_idx = 0;
        }
        else
            buffer[buf_idx++] = current_char;

        // 3. Reset for next byte
        current_char = 0;
        bit_idx = 0;
    }

    // 4. Send ACK to client
    kill(info->si_pid, SIGUSR1);
}

int main(void)
{
    struct sigaction sa;

    // 1. Print PID
    printf("Server PID: %d\n", getpid());
    fflush(stdout);

    // 2. Configure signal handler
    sa.sa_sigaction = sig_handler;
    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, NULL);
    sigaction(SIGUSR2, &sa, NULL);

    // 3. Infinite wait loop
    while (1)
        pause();

    return (0);
}
