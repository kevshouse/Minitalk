#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

#define BUFFER_SIZE 1024

static void	handle_signal(int sig, siginfo_t *info, void *context)
{
	static char	buffer[BUFFER_SIZE];
	static int	buf_index = 0;
	static char	current_char = 0;
	static int	bit_counter = 0;

	(void)context;

	// 1. Decode the bit (SIGUSR1=0, SIGUSR2=1)
	// "|=" represents bit-wise OR.
	current_char |= (sig == SIGUSR2) << bit_counter;
	bit_counter++;

	// 2. When full byte received
	if (bit_counter == 8)
	{
		// 3. Handle message termination or buffer overflow
		if (current_char == '\0' || buf_index == BUFFER_SIZE - 1)
		{
			buffer[buf_index] = '\0';
			write(STDOUT_FILENO, buffer, buf_index);
			write(STDOUT_FILENO, "\n", 1);
			buf_index = 0;
		}
		else
		{
			buffer[buf_index++] = current_char;
		}
		
		// 4. Reset for next character
		current_char = 0;
		bit_counter = 0;
	}

	// 5. Send ACK to client
	kill(info->si_pid, SIGUSR1);
}

int	main(void)
{
	struct sigaction	sa;

	// [Previous setup code: print PID, configure sigaction...]

	// Main loop (signal-driven)
	while (1)
		pause();
	return (0);
}
