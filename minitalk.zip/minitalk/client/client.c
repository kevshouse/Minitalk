#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

// Global transmission state
typedef struct {
    const char  *message;
    int         char_idx;
    int         bit_idx;
    pid_t       server_pid;
} t_transmission;

static volatile sig_atomic_t g_ack_received = 0;
static t_transmission g_tx;

// ACK handler
void    ack_handler(int sig)
{
    (void)sig;
    g_ack_received = 1;
}

// Send single bit with ACK wait
void    send_bit(int bit)
{
    sigset_t mask;

    sigemptyset(&mask);
    sigaddset(&mask, SIGUSR1);
    sigprocmask(SIG_BLOCK, &mask, NULL);

    g_ack_received = 0;
    kill(g_tx.server_pid, bit ? SIGUSR2 : SIGUSR1);

    while (!g_ack_received)
        sigsuspend(&mask);

    sigprocmask(SIG_UNBLOCK, &mask, NULL);
}

// Send entire message
void    send_message(const char *msg, pid_t pid)
{
    struct sigaction sa;

    // Configure ACK handler
    sa.sa_handler = ack_handler;
    sa.sa_flags = 0;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, NULL);

    // Initialize transmission
    g_tx = (t_transmission){msg, 0, 0, pid};

    // Send all characters
    while (g_tx.message[g_tx.char_idx])
    {
        char c = g_tx.message[g_tx.char_idx];
        for (int i = 0; i < 8; i++)
        {
            int bit = (c >> i) & 1; // LSB-first
            send_bit(bit);
        }
        g_tx.char_idx++;
    }

    // Send null terminator
    for (int i = 0; i < 8; i++)
        send_bit(0);
}

int main(int argc, char **argv)
{
    if (argc != 3)
    {
        write(2, "Usage: ./client [PID] [message]\n", 32);
        return (1);
    }

    pid_t pid = atoi(argv[1]);
    send_message(argv[2], pid);
    return (0);
}
