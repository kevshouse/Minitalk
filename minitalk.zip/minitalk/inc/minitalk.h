#ifndef MINITALK_H
# define MINITALK_H

# define MY_SIG_BIT0 SIGUSR1
# define MY_SIG_BIT1 SIGUSR2

# include <signal.h>
# include <unistd.h>
# include <stdlib.h>
# include "libft.h"

#endif
