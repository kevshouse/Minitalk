#!/bin/bash
set -eo pipefail

cleanup() {
    echo "=== Cleaning up ==="
    pkill -P $$ server || true
    rm -f "$TEST_MSG_FILE" "$OUTPUT_FILE"
}

trap 'cleanup; exit 1' ERR

SERVER_EXEC="./server"
CLIENT_EXEC="./client"
TEST_CHARS=30000
OUTPUT_FILE="server_output.txt"
TEST_MSG_FILE="test_message.txt"

echo "=== Executable Check ==="
[ -f "$SERVER_EXEC" ] || { echo "❌ Server missing"; exit 1; }
[ -f "$CLIENT_EXEC" ] || { echo "❌ Client missing"; exit 1; }

echo "=== Generating Test Message ==="
dd if=/dev/urandom bs=1 count=$TEST_CHARS 2>/dev/null | \
  base64 -w0 | \
  head -c $TEST_CHARS > "$TEST_MSG_FILE" || {
    echo "❌ Message generation failed"
    exit 1
}

echo "=== Starting Server ==="
rm -f "$OUTPUT_FILE"
"$SERVER_EXEC" > "$OUTPUT_FILE" 2>&1 &
SERVER_PID=$!
sleep 2

echo "=== Server PID Verification ==="
SERVER_PID=$(awk -F': ' '/Server PID: /{print $2}' "$OUTPUT_FILE")
[ -n "$SERVER_PID" ] || { echo "❌ No PID in output"; cat "$OUTPUT_FILE"; exit 1; }
ps -p "$SERVER_PID" >/dev/null || { echo "❌ Server not running"; exit 1; }

echo "=== Sending Message ==="
"$CLIENT_EXEC" "$SERVER_PID" "$(cat "$TEST_MSG_FILE")" || {
  echo "❌ Client failed"; exit 1
}

echo "=== Verifying ==="
sleep 5  # Wait for server to process
received=$(wc -c < "$OUTPUT_FILE")

# Calculate the length of the PID line
pid_line_length=$(grep -m 1 'Server PID:' "$OUTPUT_FILE" | wc -c)
# Add 1 for the newline character after the PID line
pid_line_length=$((pid_line_length + 1))

# Adjust the expected size
expected_size=$((TEST_CHARS + pid_line_length + 1))  # +1 for the newline after the message

# Check for additional newlines that might be added
# If the server adds a newline after the message, we need to account for that
expected_size=$((expected_size + 1))  # Account for the additional newline

# Debugging output
echo "Received: $received bytes, Expected: $expected_size bytes"

if [ "$received" -eq "$expected_size" ]; then
    echo "✅ Size matches: Received $received bytes, Expected $expected_size bytes"
else
    echo "❌ Size mismatch: Received $received bytes, Expected $expected_size bytes"
fi

cleanup
echo "✅ Stress test completed"
