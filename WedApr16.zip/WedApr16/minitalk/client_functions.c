/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client_functions.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/16 11:31:31 by keanders          #+#    #+#             */
/*   Updated: 2025/04/16 17:25:47 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minitalk.h"
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

static volatile sig_atomic_t g_ack_received;

void handle_error(const char *msg)
{
    ft_putstr_fd(msg, STDERR_FILENO);
    exit(EXIT_FAILURE);
}

void send_signal(pid_t pid, int signal)
{
    if (kill(pid, signal) == -1)
        handle_error("Error: kill() failed - ");
}

void wait_for_ack(int retries)
{
    if (g_ack_received || retries >= MAX_RETRIES)
        return;
    usleep(ACK_DELAY_US * (retries + 1));
    wait_for_ack(retries + 1);
}

void ack_handler(int sig)
{
    g_ack_received = 1; // Set acknowledgment status
}

void send_bit(pid_t pid, int bit)
{
    int signal = (bit == 1) ? MY_SIG_BIT1 : MY_SIG_BIT0;
    int retries = 0;

    g_ack_received = 0;
    send_signal(pid, signal);
    wait_for_ack(retries);

    if (retries >= MAX_RETRIES)
        handle_error("Error: No ACK received\n");
}

void send_char(pid_t pid, char c)
{
    int i;
    for (i = 7; i >= 0; i--)
    {
        send_bit(pid, (c >> i) & 1);
    }
}

void transmit_message(t_client_state *state)
{
    int i = 0;
    while (state->message[i])
    {
        send_char(state->server_pid, state->message[i]);
        i++;
    }
    send_char(state->server_pid, '\0'); // Send null terminator
}