#include <signal.h>
#include <stdio.h>
#include <unistd.h>

volatile sig_atomic_t	ack_received = 0;

void	ack_handler(int sig)
{
	ack_received = 1;
}

int	main(void)
{
	struct sigaction	sa;

	sa.sa_handler = ack_handler;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = 0;
	sigaction(SIGUSR1, &sa, NULL);
	sigaction(SIGUSR2, &sa, NULL);
	printf("Waiting for acknowledgment signals...\n");
	while (1)
	{
		pause();
		if (ack_received)
		{
			//printf("Acknowledgment received!\n");
			ack_received = 0;
		}
	}
	return (0);
}
