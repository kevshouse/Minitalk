#include <stdio.h>

void send_message(const char *message) {
    printf("Sending message: %s\n", message);
}

int main() {
    const char *test_message = "Hello, this is a test message.";
    send_message(test_message);
    return 0;
}
