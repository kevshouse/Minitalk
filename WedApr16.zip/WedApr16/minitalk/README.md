```Directory Structure

minitalk/
├── include/
│   └── minitalk.h       # Consolidated header (mandatory + bonus)
├── src/
│   ├── client/          # Client-side components
│   │   ├── main.c
│   │   ├── signal.c
│   │   └── transmit.c
│   ├── server/          # Server-side components
│   │   ├── main.c
│   │   ├── handler.c
│   │   └── client_db.c
│   └── shared/          # Common utilities
│       ├── utils.c
│       ├── error.c
│       └── protocol.c
├── Makefile
└── README.md
```
Core Function Prototypes & Documentation
1. Client-Side Functions (src/client/)
```c

/**
 * @brief Initialize client state and validate input
 * @param argv Command-line arguments [server_pid, message]
 * @return Initialized t_client_state struct
 * @note Mandatory
 */
t_client_state client_init(char *argv[]);

/**
 * @brief Send single bit via SIGUSR1/SIGUSR2
 * @param state Client state container
 * @param bit Bit to send (0 or 1)
 * @return 0 on success, -1 on failure (after MAX_RETRIES)
 * @note Mandatory
 */
int send_bit(t_client_state *state, int bit);

/**
 * @brief Signal handler for server acknowledgments
 * @param sig Received signal (SIGUSR1/SIGUSR2)
 * @param info Signal info struct
 * @param context Unused parameter
 * @note Bonus
 */
void ack_handler(int sig, siginfo_t *info, void *context);

/**
 * @brief Transmit entire message with flow control
 * @param state Initialized client state
 * @note Handles both mandatory and bonus requirements
 */
```
void transmit_message(t_client_state *state);
2. Server-Side Functions (src/server/)
```c

/**
 * @brief Main signal handler for incoming messages
 * @param sig Received signal (SIGUSR1/SIGUSR2)
 * @param info Signal info containing client PID
 * @param context Unused parameter
 * @note Mandatory base functionality
 */
void sig_handler(int sig, siginfo_t *info, void *context);

/**
 * @brief Process received bits and build message
 * @param c Pointer to client structure
 * @param bit Received bit value
 * @note Handles both mandatory and bonus
 */
void process_bit(t_client *c, int bit);

/**
 * @brief Manage client database (add/update/remove)
 * @param pid Client process ID to manage
 * @return Pointer to client struct, NULL if full
 * @note Mandatory for multi-client support
 */
t_client *manage_client(pid_t pid);

/**
 * @brief Validate UTF-8 byte sequences
 * @param c Client structure with received bytes
 * @return 1 if valid, 0 if invalid (resets client state)
 * @note Bonus requirement
 */
int validate_utf8(t_client *c);
```
3. Shared Utilities (src/shared/)
```c

/**
 * @brief Safe wrapper for kill() system call
 * @param pid Target process ID
 * @param sig Signal to send
 * @return 0 on success, -1 on error (logs details)
 * @note Mandatory for error handling
 */
int safe_kill(pid_t pid, int sig);

/**
 * @brief Custom string writer with error checking
 * @param fd File descriptor (STDOUT/STDERR)
 * @param str Null-terminated string to write
 * @note Mandatory base requirement
 */
void ft_putstr_fd(int fd, char *str);

/**
 * @brief Convert string to integer with validation
 * @param str Input string
 * @return Converted number, exits on invalid input
 * @note Mandatory for PID validation
 */
int ft_atoi_validate(const char *str);

/**
 * @brief Send acknowledgment signal to client
 * @param pid Target client PID
 * @param sig_type ACK_SUCCESS or ACK_FAILURE
 * @note Bonus requirement
 */
void send_ack(pid_t pid, int sig_type);
```
Data Structures (minitalk.h)
```c

// Client transmission state
typedef struct s_client_state {
    pid_t server_pid;
    char *message;
    size_t bit_index;
    size_t retries;
    struct sigaction old_act;
} t_client_state;

// Server-side client tracking
typedef struct s_client {
    pid_t pid;
    char buffer[BUFFER_SIZE];
    size_t bit_count;
    time_t last_contact;
    uint8_t checksum;
} t_client;

// Shared constants
enum {
    SIG_BIT0 = SIGUSR1,
    SIG_BIT1 = SIGUSR2,
    MAX_RETRIES = 3,
    CLIENT_TIMEOUT = 5 // Seconds
};
```
Implementation Guidelines
Signal Sequencing

Use SIGUSR1 for 0 bits, SIGUSR2 for 1 bits
Message format: [LSB-first char bits][NULL terminator]
Acknowledgment Protocol (Bonus)

```c

// Server -> Client signals
#define ACK_SUCCESS SIGUSR1
#define ACK_FAILURE SIGUSR2
```
Server sends ACK_SUCCESS after each byte received correctly
ACK_FAILURE triggers client retransmission
Unicode Handling

Validate UTF-8 continuation bytes in validate_utf8()
Use bitmask checks for multi-byte sequences:
```c
Run
Copy code
// In validate_utf8():
if ((c->buffer[0] & 0xE0) == 0xC0) { // 2-byte sequence
    if(c->bit_count != 8*2) return 0; 
}
```
Timeout System

Server calls cleanup_clients() periodically:
```c

void cleanup_clients() {
    for(int i = 0; i < MAX_CLIENTS; i++){
        if(time(NULL) - g_clients[i].last_contact > CLIENT_TIMEOUT){
            memset(&g_clients[i], 0, sizeof(t_client));
        }
    }
}
```
### Suggested Implementation Order
Implement mandatory client-server communication:
```bash
client_init() → transmit_message() → send_bit()
Server-side: sig_handler() → process_bit()
Add error handling and validation:

safe_kill() → ft_atoi_validate()
Implement bonus features:

ack_handler() → send_ack() → validate_utf8()
Add advanced features:

Client retransmission logic
Server-side client database
```
