#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void safe_kill(pid_t pid, int sig) {
    if (kill(pid, sig) == -1) {
        perror("Error: kill failed");
        exit(EXIT_FAILURE);
    }
}

int main() {
    pid_t test_pid = getpid(); // Use current process for testing
    printf("Sending signal to self (PID: %d)\n", test_pid);
    safe_kill(test_pid, SIGUSR1); // Send SIGUSR1 to self
    return 0;
}
