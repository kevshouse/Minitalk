#include <stdio.h>

void encode_char(char c) {
    for (int i = 7; i >= 0; i--) { // Start from bit 7 down to bit 0
        if (c & (1 << i)) {
            printf("1");
        } else {
            printf("0");
        }
    }
    printf("\n");
}

int main() {
    char test_char = 'o';  // ASCII HEX 6F
    printf("Encoding character '%c': ", test_char);
    encode_char(test_char);
    return 0;
}
