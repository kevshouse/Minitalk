#include <stdio.h>
#include <string.h>

#define BUFFER_SIZE 100 // Increased buffer size for testing

int main() {
    char buffer[BUFFER_SIZE];
    
    // Test with a short string
    strcpy(buffer, "Hello"); 
    printf("Buffer content: %s\n", buffer);

    // Test with a long string that fits within the buffer
    strcpy(buffer, "This is a long string that fits within the buffer size.");
    printf("Buffer content after valid copy: %s\n", buffer);

    // Test with a long string that exceeds the buffer size
    // Use strncpy to prevent overflow
    strncpy(buffer, "This is a very long string that exceeds the buffer size.", BUFFER_SIZE - 1);
    buffer[BUFFER_SIZE - 1] = '\0'; // Ensure null termination
    printf("Buffer content after overflow attempt: %s\n", buffer);
    
    return 0;
}
