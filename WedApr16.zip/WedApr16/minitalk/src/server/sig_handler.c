/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sig_handler.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/16 11:50:43 by keanders          #+#    #+#             */
/*   Updated: 2025/04/16 22:42:38 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minitalk.h"
#include <signal.h>
#include <unistd.h>

/*static void	sig_handler(int sig, siginfo_t *info, void *context)
{
	static int	bit_count;
	static char	c;
	static pid_t	client_pid;

	(void)context;
	if (!client_pid)
		client_pid = info->si_pid;
	if (client_pid != info->si_pid)
		return ;
	c |= (sig == MY_SIG_BIT1) << bit_count;
	bit_count++;
	if (bit_count == 8)
	{
		if (c)
			write(1, &c, 1);
		else
			write(1, "\n", 1);
		bit_count = 0;
		c = 0;
	}
	usleep(50);
	kill(client_pid, MY_SIG_BIT0);
}*/

static void sig_handler(int sig, siginfo_t *info, void *context)
{
    static pid_t client_pid;
    static int bit_count;
    static char c;

    c = 0;
    bit_count = 0;
    client_pid = 0;
    (void)context;

    if (!client_pid)
        client_pid = info->si_pid;
    if (client_pid != info->si_pid)
        return;

    c |= (sig == MY_SIG_BIT1) << bit_count;
    bit_count++;

    if (bit_count == 8) {
        if (c)
            write(1, &c, 1);
        else
            write(1, "\n", 1);
        bit_count = 0;
        c = 0;
    }
    usleep(50);
    kill(client_pid, MY_SIG_BIT0);
}
