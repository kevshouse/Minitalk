/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/12 13:19:05 by keanders          #+#    #+#             */
/*   Updated: 2025/02/14 14:06:44 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static void handle_specifier(char spec, va_list args, int *count)
{
    if (spec == '%')
        pf_putchar('%', count);
    else if (spec == 'c')
        pf_putchar(va_arg(args, int), count);
    else if (spec == 's')
        pf_putstr(va_arg(args, char *), count);
    else if (spec == 'd' || spec == 'i')
        pf_putnbr(va_arg(args, int), count);
    else if (spec == 'x')
        pf_puthex(va_arg(args, unsigned int), 0, count);
    else if (spec == 'X')
        pf_puthex(va_arg(args, unsigned int), 1, count);
    else if (spec == 'u')
        pf_putunsigned(va_arg(args, unsigned int), count);
    else if (spec == 'p')
        pf_putptr(va_arg(args, unsigned long), count);
}

int ft_printf(const char *format, ...)
{
    va_list args;
    int     count;

    count = 0;
    va_start(args, format);
    while (*format)
    {
        if (*format == '%')
        {
            format++;
            handle_specifier(*format, args, &count);
        }
        else
            pf_putchar(*format, &count);
        format++;
    }
    va_end(args);
    return (count);
}
