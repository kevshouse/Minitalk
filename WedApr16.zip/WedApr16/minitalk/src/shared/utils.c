//ft_atoi_validate, ft_putstr_fd
#include "../../inc/minitalk.h"



int ft_isspace(int c)
{
    return (c == ' ' || c == '\t' || c == '\n' || c == '\v' || c == '\f' || c == '\r');
}

int ft_isdigit(int c)
{
    if (c >= '0'&& c <= '9')
        return (1);
    else
        return (0);
}

int	ft_isdigit_str(const char *str)
{
	while (*str)
	{
		if (!ft_isdigit(*str))
			return (0);
		str++;
	}
	return (1);
}

void	ft_putchar_fd(char c, int fd)
{
	write(fd, &c, 1);
}

void	ft_putstr_fd(char *str, int fd)
{
	int		i;

	i = 0;
	while (str[i] != '\0')
	{
		ft_putchar_fd(str[i], fd);
		i++;
	}
}

int	ft_atoi(const char *str)
{
	int		result;
	int		sign;
	int		i;

	result = 0;
	sign = 1;
	i = 0;
	while (str[i] == '\t' || str[i] == '\n' || str[i] == '\v'
		|| str[i] == '\f' || str[i] == '\r' || str[i] == ' ')
		i++;
	if (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			sign = -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		result = result * 10 + (str[i] - '0');
		i++;
	}
	return (result * sign);
}

int	ft_atoi_validate(const char *str)
{
	int		i;
	long	result;

	i = 0;
	if (str == NULL || *str == '\0')
	{
		fprintf(stderr, "Error: Empty of Null string\n");
		exit(EXIT_FAILURE);
	}
	while (str[i] != '\0')
	{
		if (!ft_isdigit(str[i]))
		{
			fprintf(stderr, "Error: Invalid char '%c' in input\n", str[i]);
			exit(EXIT_FAILURE);
		}
		i++;
	}
	i = 0;
	result = 0;
	return (ft_atoi(str));
}
