 #include "../../inc/minitalk.h"

/* Shared global for signal safety */
static volatile sig_atomic_t g_ack_status = ACK_PENDING;

// ================= BIT PROTOCOL =================

void encode_char(char c, int *signals)
{
    static int bit_pos = 0;

    for (int i = 0; i < 8; i++)
    {
        signals[bit_pos++] = (c & (1 << i)) ? SIG_BIT1 : SIG_BIT0;
        if (bit_pos >= BUFFER_SIZE) bit_pos = 0;
    }
}

char decode_bits(t_client *client)
{
    char c = 0;

    for (int i = 0; i < 8; i++)
    {
        if (client->bits[i] == SIG_BIT1)
            c |= (1 << i);
    }
    if (BONUS)
    {
        client->checksum ^= c;
        if ((client->bit_count % 8) == 0 && !validate_utf8(client))
            return (char)0xFF; // Invalid marker
    }
    return (c);
}

// ================= TRANSMISSION CONTROL =================

int handle_retransmit(t_client_state *state)
{
    static int retries = 0;

    if (g_ack_status == ACK_SUCCESS)
    {
        retries = 0;
        return 0;
    }
    if (++retries > MAX_RETRIES)
    {
        ft_putstr_fd(STDERR_FILENO, "FATAL: No server response\n");
        exit(EXIT_FAILURE);
    }
    usleep(ACK_TIMEOUT_US * retries); // Exponential backoff
    return 1;
}

void send_ack(pid_t pid, int ack_type)
{
    struct sigaction old;

    sigemptyset(&old.sa_mask);
    old.sa_flags = 0;
    if (sigaction(ack_type, NULL, &old) == -1)
        return;
    if (old.sa_handler == SIG_IGN || kill(pid, ack_type) == -1)
        return;
}

// ================= CLIENT-SERVER SYNC =================

void update_transmission_state(int sig, siginfo_t *info, void *context)
{
    (void)context;
    if (info->si_pid != g_client.pid)
        return;

    if (sig == ACK_SUCCESS) {
        g_ack_status = ACK_SUCCESS;
        g_client.bit_index++;
    } else {
        g_ack_status = ACK_RETRY;
    }
}

// ================= CHECKSUM (BONUS) =================
//use calculate_checksum(const char *str)
/*
uint8_t calculate_checksum(const char *str)// uses bitwise OR
{
    uint8_t sum = 0;

    while (*str)
        sum ^= *str++;
    return (sum);
}
*/
// ================= CLIENT DB (SERVER-SIDE) =================

t_client *manage_client_db(pid_t pid, int action)
{
    static t_client clients[MAX_CLIENTS];
    static size_t count = 0;

    for (size_t i = 0; i < count; i++)
        {
        if (clients[i].pid == pid)
        {
            clients[i].last_seen = time(NULL);
            return (&clients[i]);
        }
    }

    if (action == ADD_CLIENT && count < MAX_CLIENTS)
        {
        clients[count] = (t_client){
            .pid = pid,
            .bit_count = 0,
            .last_seen = time(NULL),
            .checksum = 0
        };
        return (&clients[count++]);
    }

    return NULL;
}scratch-encode_char
