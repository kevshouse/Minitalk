/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client_functions.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/15 20:15:00 by keanders          #+#    #+#             */
/*   Updated: 2025/04/16 22:55:36 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/client_functions.h"
#include "../../inc/minitalk.h"
#include <signal.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static atomic_int	g_ack_received = 0;

void	ack_handler(int sig)
{
	(void)sig;
	atomic_store(&g_ack_received, 1);
	//printf("Ack rec for signal: %d\n", sig);
}

void send_signal(pid_t pid, int signal)
{
    if (kill(pid, signal) == -1)
    {
        perror("Error: kill() failed"); // This will print the specific error
        exit(EXIT_FAILURE);
    }
    //printf("Signal %d sent to PID %d\n", signal, pid);
}


void	wait_for_ack(int retries)
{
	if (atomic_load(&g_ack_received) || retries >= MAX_RETRIES)
		return ;
	usleep(ACK_DELAY_US * (retries + 1));
	wait_for_ack(retries + 1);
}

void	send_bit(pid_t pid, int bit)
{
	int	signal;
	int	retries;

	retries = 0;
	if (bit == 1)
	{
		signal = MY_SIG_BIT1;
	}
	else
	{
		signal = MY_SIG_BIT0;
	}
	atomic_store(&g_ack_received, 0);
	send_signal(pid, signal);
	//printf("Signal %d sent to PID %d\n", signal, pid); // Debugging output
	wait_for_ack(retries);
	if (retries >= MAX_RETRIES)
	{
		ft_putstr_fd("Error: No ACK received\n", STDERR_FILENO);
		exit(EXIT_FAILURE);
	}
	//printf("BIT %d ,sent ok\n", bit);
}

void	send_char(pid_t pid, char c)
{
	//int		signals[8];
	int		i;
	int		bit;
	// Allow sending a null character to indicate the end of the message
    if (c == '\0') {
        // Optionally, you can log that a null character is being sent
        //printf("Sending null character to indicate end of message.\n");
        return; // Just return without sending a signal
    }

	i = 7;
	printf("Sending character: '%c' (ASCII: %d)\n", c, c); // Debugging output
	while (i >= 0)
	{
		bit = (c >> i) & 1;
		send_bit(pid, bit);
		printf("Bit %d sent for character '%c'\n", bit, c); // Debugging output
		i--;
	}
}
