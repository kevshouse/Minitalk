#include "../../inc/minitalk.h"
#include "../../inc/client_functions.h"
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <limits.h>

static volatile sig_atomic_t	g_ack_received;

int	main(int argc, char **argv)
{
	struct sigaction	sa;
	pid_t				pid;
	char				*message;

	if (argc != 3)
	{
		ft_putstr_fd("Usage: ./client <PID> <message>\n", STDERR_FILENO);
		exit(EXIT_FAILURE);
	}
	pid = ft_atoi_validate(argv[1]);
	if (pid <= 0)
	{
		ft_putstr_fd("Error: Invalid PID\n", STDERR_FILENO);
		exit(EXIT_FAILURE);
	}
	sa.sa_handler = ack_handler;
	sa.sa_flags = 0;
	sigemptyset(&sa.sa_mask);
	sigaction(MY_SIG_BIT0, &sa, NULL);
	message = argv[2];
	// Check if the message is empty
	if (message == NULL || *message == '\0')
	{
    //printf("No message to send.\n"); // Debugging output
    return (EXIT_SUCCESS);
	}
	while (*message)
		send_char(pid, *message++);
	send_char(pid, '\0');
	return (EXIT_SUCCESS);
}
