/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client_functions.h                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/16 12:58:13 by keanders          #+#    #+#             */
/*   Updated: 2025/04/16 19:21:49 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CLIENT_FUNCTIONS_H
# define CLIENT_FUNCTIONS_H

# include "minitalk.h"

void	ack_handler(int sig);
void	send_signal(pid_t pid, int signal);
void	wait_for_ack(int retries);
void	send_bit(pid_t pid, int bit);
void	send_char(pid_t pid, char c);

void	transmit_message(t_client *state);

void	encode_char(char c, int signals[8]);

#endif