/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minitalk.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/16 12:58:13 by keanders          #+#    #+#             */
/*   Updated: 2025/04/16 19:05:12 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINITALK_H
# define MINITALK_H

# include <limits.h>
# include <stdio.h>
# include <signal.h>
# include <stdint.h>
# include <stdlib.h>
# include <string.h>
# include <sys/types.h>
# include <unistd.h>
#include <stdatomic.h>
# define MY_SIG_BIT0 SIGUSR1
# define MY_SIG_BIT1 SIGUSR2
# define BUFFER_SIZE 1024
# define MAX_RETRIES 10
# define ACK_DELAY_US 1000
# define CLIENT_TIMEOUT 5

int			ft_atoi_validate(const char *str);
int			ft_isdigit(int c);
int			ft_isspace(int c);
void		ft_putchar_fd(char c, int fd);
void		ft_putstr_fd(const char *str, int fd);
void		ft_putnbr_fd(int n, int fd);

typedef struct s_client
{
	pid_t	pid;
	size_t	bit_count;
	uint8_t	checksum;
	char	buffer[BUFFER_SIZE];
}			t_client;

#endif
