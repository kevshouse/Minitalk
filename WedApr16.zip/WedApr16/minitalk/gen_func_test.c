#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <stdatomic.h>

#define BUFFER_SIZE 1024
#define MAX_RETRIES 3
#define ACK_DELAY_US 1000

// Function prototypes
void encode_char(char c);
void test_buffer();
void test_message(pid_t pid);
void test_race_condition();
void send_bit(pid_t pid, int bit);
void send_char(pid_t pid, char c);
void ack_handler(int sig);

// Global variable for acknowledgment
static volatile sig_atomic_t g_ack_received = 0;

int main() {
    // Set up signal handlers for acknowledgment
    struct sigaction sa;
    sa.sa_handler = ack_handler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, NULL); // ACK_SUCCESS
    sigaction(SIGUSR2, &sa, NULL); // ACK_FAILURE

    // Test bit encoding
    char test_char = 'o';  // ASCII HEX 6F
    printf("Encoding character '%c': ", test_char);
    encode_char(test_char);

    // Test buffer handling
    test_buffer();

    // Test message sending
    pid_t dummy_pid = getpid(); // Using current process for demonstration
    printf("\nSending message to PID %d...\n", dummy_pid);
    test_message(dummy_pid);

    // Test race condition handling
    test_race_condition();

    return 0;
}

// Function to encode a character into binary representation
void encode_char(char c) {
    for (int i = 7; i >= 0; i--) { // Start from bit 7 down to bit 0
        if (c & (1 << i)) {
            printf("1");
        } else {
            printf("0");
        }
    }
    printf("\n");
}

// Function to test buffer handling
void test_buffer() {
    char buffer[BUFFER_SIZE];
    
    // Test with a short string
    strcpy(buffer, "Hello");
    printf("Buffer content: %s\n", buffer);

    // Test with a long string that fits within the buffer
    strcpy(buffer, "This is a long string that fits within the buffer size.");
    printf("Buffer content after valid copy: %s\n", buffer);

    // Test with a long string that exceeds the buffer size
    strncpy(buffer, "This is a very long string that exceeds the buffer size.", BUFFER_SIZE - 1);
    buffer[BUFFER_SIZE - 1] = '\0'; // Ensure null termination
    printf("Buffer content after overflow attempt: %s\n", buffer);
}

// Function to simulate sending a message
void test_message(pid_t pid) {
    char message[] = "Hello, this is a test message.";
    for (int i = 0; i < strlen(message); i++) {
        send_char(pid, message[i]);
    }
    send_char(pid, '\0'); // Send null terminator
}

// Function to send a single bit
void send_bit(pid_t pid, int bit) {
    int signal = bit ? SIGUSR2 : SIGUSR1; // Assuming SIGUSR1 for 0 and SIGUSR2 for 1
    g_ack_received = 0;

    if (kill(pid, signal) == -1) {
        perror("Error: kill() failed");
        exit(EXIT_FAILURE);
    }

    // Wait for acknowledgment
    usleep(ACK_DELAY_US);
}

// Function to send a character
void send_char(pid_t pid, char c) {
    for (int i = 7; i >= 0; i--) { // Send from MSB to LSB
        send_bit(pid, (c >> i) & 1);
    }
}

// Acknowledgment handler
void ack_handler(int sig) {
    g_ack_received = 1;
}

// Function to test race condition handling
void test_race_condition() {
    printf("Waiting for acknowledgment signals...\n");
    while (!g_ack_received) {
        pause(); // Wait for signal
    }
    printf("Acknowledgment received!\n");
}
