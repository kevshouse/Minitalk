#include <stdio.h>

void encode_char(char c) {
    for (int i = 0; i < 8; i++) {
        if (c & (1 << i)) {
            printf("1");
        } else {
            printf("0");
        }
    }
    printf("\n");
}

int main() {
    //char test_char = 'A'; // ASCII HEX 41
    //char test_char = '~'; // ASCII HEX 7E
    char test_char = '\0'; // ASCII NULL HEX 00
    printf("Encoding character '%c': ", test_char);
    encode_char(test_char);
    return 0;
}
