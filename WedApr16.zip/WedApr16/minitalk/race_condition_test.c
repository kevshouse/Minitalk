#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdatomic.h>

volatile sig_atomic_t g_ack_status = 0;

void ack_handler(int sig) {
    g_ack_status = 1; // Set acknowledgment status
}

int main() {
    struct sigaction sa;
    sa.sa_handler = ack_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    sigaction(SIGUSR1, &sa, NULL);

    printf("Waiting for acknowledgment...\n");
    while (g_ack_status == 0) {
        pause(); // Wait for signal
    }
    printf("Acknowledgment received!\n");
    return 0;
}
