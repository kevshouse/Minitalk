#include <stdio.h>
#include <signal.h>
#include <unistd.h>

void sig_handler(int sig) {
    if (sig == SIGUSR1) {
        printf("Received SIGUSR1\n");
    } else if (sig == SIGUSR2) {
        printf("Received SIGUSR2\n");
    }
}

int main() {
    struct sigaction sa;
    sa.sa_handler = sig_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    sigaction(SIGUSR1, &sa, NULL);
    sigaction(SIGUSR2, &sa, NULL);

    printf("Send SIGUSR1 or SIGUSR2 to this process (PID: %d)\n", getpid());
    while (1) {
        pause(); // Wait for signals
    }
    return 0;
}
