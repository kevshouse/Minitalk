#!/bin/bash

# Check if the number of times to run the script and the wildcard pattern are provided
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <script_pattern> <number_of_times>"
    exit 1
fi

script_pattern="$1"
n_times="$2"

# Loop through all scripts matching the wildcard pattern
for script_to_run in $script_pattern; do
    # Check if the script exists and is executable
    if [ -x "$script_to_run" ]; then
        for ((i = 1; i <= n_times; i++)); do
            echo "Running $script_to_run - Run #$i:"
            ./"$script_to_run"  # Run the script
        done
    else
        echo "Warning: $script_to_run is not executable or does not exist."
    fi
done