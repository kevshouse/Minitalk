
//34567890

int     hard_tab;

hard_tab = 4;
    return 0;
