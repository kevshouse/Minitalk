#!/bin/bash

# Function to generate a random UTF-8 character
random_char() {
    # Generate a random number between 0 and 127 (ASCII range)
    # You can adjust the range to include more characters if needed
    local char_code=$((RANDOM % 94 + 33))  # Printable ASCII characters from 33 to 126
    printf "\\$(printf '%03o' "$char_code")"
}

# Function to create a 16x16 grid
create_grid() {
    local border_char=$(random_char)  # Random border character
    local inner_char=$(random_char)   # Random inner character

    # Ensure the inner character is different from the border character
    while [ "$inner_char" == "$border_char" ]; do
        inner_char=$(random_char)
    done

    # Print the grid
    for ((i = 0; i < 16; i++)); do
        for ((j = 0; j < 16; j++)); do
            if ((i == 0 || i == 15 || j == 0 || j == 15)); then
                # Print border character
                printf "%s" "$border_char"
            else
                # Print inner character
                printf "%s" "$inner_char"
            fi
        done
        echo  # New line after each row
    done
}

# Main script execution
create_grid