#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include "libft.h"

#define MAX_CLIENTS 10

typedef struct s_client
{
    int         pid;
    char        buffer[5];
    int         bit_count;
    int         byte_count;
    size_t      expected_bytes;
} t_client;

static t_client g_clients[MAX_CLIENTS];

// Find/Create client entry
static t_client *get_client(int pid)
{
    for (int i = 0; i < MAX_CLIENTS; i++)
    {
        if (g_clients[i].pid == pid || g_clients[i].pid == 0)
        {
            if (g_clients[i].pid == 0)
                ft_memset(&g_clients[i], 0, sizeof(t_client));
            g_clients[i].pid = pid;
            return &g_clients[i];
        }
    }
    return (NULL);
}

// Detect UTF-8 sequence length -- RENAME to get_utf8_length
static void detect_utf8_length(t_client *c)
{
    if ((c->buffer[0] & 0b11110000) == 0b11110000) c->expected_bytes = 4;
    else if ((c->buffer[0] & 0b11100000) == 0b11100000) c->expected_bytes = 3;
    else if ((c->buffer[0] & 0b11000000) == 0b11000000) c->expected_bytes = 2;
    else c->expected_bytes = 1;
}

// Signal Handler
void handle_signal(int sig, siginfo_t *info, void *context)
{
    (void)context;
    t_client *client = get_client(info->si_pid);
    if (!client) return;

    client->buffer[client->byte_count] |= ((sig == SIGUSR1 ? 0 : 1) << (7 - client->bit_count++));
    
    if (client->bit_count == 8)
    {
        client->bit_count = 0;
        if (client->byte_count == 0)
            detect_utf8_length(client);
        if (++client->byte_count == client->expected_bytes)
        {
            write(1, client->buffer, client->expected_bytes);
            ft_memset(client, 0, sizeof(t_client));
        }
    }
    kill(info->si_pid, SIGUSR1); // Send ACK
}

int main(void) {
    ft_printf("Server PID: %d\n", getpid());
    
    struct sigaction sa = {0};
    sa.sa_sigaction = handle_signal;
    sa.sa_flags = SA_SIGINFO;
    sigaction(SIGUSR1, &sa, NULL);
    sigaction(SIGUSR2, &sa, NULL);

    while (1)
        pause();
    return (0);
}
