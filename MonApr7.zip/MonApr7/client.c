/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/07 16:11:56 by keanders          #+#    #+#             */
/*   Updated: 2025/04/07 16:47:06 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include "minitalk.h"

#define TIMEOUT_SEC 1
#define MAX_RETRIES 5

static		t_state g_state;

g_state.current_bit = 0;
g_state.ack_receaved = 0;
g_state.retries = 0;

// Timeout Handler
void	handle_timeout(int sig)
{
	int		signal_to_send;

	(void)sig;
	if (g_state.retries++ < MAX_RETRIES && !g_state.ack_received)
	{
		if (g_state.message[0] & (1 << (7 -g_state.current_bit)))
			signal_to_send = SIGUSR2;
		else
			signal_to_send = SIGUSR1;
	}
	kill(g_state.server_pid, signal_to_send);
	alarm(TIMEOUT_SEC);
}

// ACK Handler
void	handle_ack(int sig, siginfo_t *info, void *context)
{
	(void)sig;
	(void)context;
	if (info->si_pid == g_state.server_pid)
	{
		g_state.ack_received = 1;
		alarm(0);
	}
}

void	send_bit(void)
{
	int		bit;

	g_state.ack_received = 0;
	g_state.retries = 0;
	bit = g_state.message[0] & (1 << (7 - g_state.current_bit));
	if (bit)
		kill (g_state.server_pid, SIGUSR2);
	else
		kill (g_state.server_pid, SIGUSR1);
	while (!g_state.ack_received)
		pause();
	g_state.current_bit++;
}

// Send full message
void	send_message(void)
{
	while (*g_state.message)
	{
		g_state.current_bit = 0;
		while (g_state.current_bit < 8)
			send_bit();
		g_state.message++;
	}
}

int main(int argc, char **argv)
{
	struct sigaction sa_ack;

	if (argc != 3 || !ft_isdigit_str(argv[1]))
	{
		ft_putstr_fd("Usage: ./client [server-pid] [message]\n", 2);
		return (1);
	}
	sa_ack = {0};
	sa_ack.sa_sigaction = handle_ack;
	sa_ack.sa_flags = SA_SIGINFO;
	sigaction(SIGUSR1, &sa_ack, NULL);
	signal(SIGALRM, handle_timeout);
	g_state = (t_state){.server_pid = ft_atoi(argv[1]), .message = argv[2]};
	send_message();
	return (0);
}
