//minitalk.h
# include <unistd.h>
# include <signal.h>
# include <stdlib.h>
# include <time.h>
# include "./libft/libft.h"  // Ensure this is included

#define TIMEOUT_SEC 1
#define MAX_RETRIES 5

// Function declaration if not already in libft.h
int ft_isdigit_str(const char *str)
    {
        while (*str)
        {
            if (!ft_isdigit(*str))
            {
                return 0; // Return false if any character is not a digit
            }
        str++;
    }
    return (1); // Return true if all characters are digits
}

typedef struct s_state
{
    int         server_pid;
    char        *message;
    int         current_bit;
    int         ack_received;
    int         retries;
} t_state;

typedef struct s_client
{
    int         pid;
    char        buffer[5];
    int         bit_count;
    int         byte_count;
    size_t      expected_bytes;
    time_t	last_active;
} t_client;

static t_client *get_client(int pid)
