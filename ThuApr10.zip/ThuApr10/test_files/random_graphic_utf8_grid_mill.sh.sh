#!/bin/bash

# Function to generate a random graphical UTF-8 character from a specified range
random_graphical_char() {
    # Define a range of graphical Unicode characters (e.g., shapes and symbols)
    local unicode_range=(
        0x25A0 0x25A1 0x25B2 0x25B3 0x25C6 0x25CB 0x25D8 0x25D9
        0x2600 0x2601 0x2602 0x2603 0x2604 0x2605 0x2606 0x2607
        0x2610 0x2611 0x2612 0x2613 0x2614 0x2615 0x2618 0x2619
        0x2620 0x2622 0x2623 0x2624 0x2625 0x2626 0x2627 0x2628
        0x2630 0x2631 0x2632 0x2633 0x2634 0x2635 0x2636 0x2637
        0x2702 0x2705 0x2708 0x2709 0x270A 0x270B 0x270C 0x270D
        0x2713 0x2714 0x2716 0x2717 0x2718 0x2719 0x271A 0x271B
        0x2721 0x2728 0x2730 0x2731 0x2732 0x2733 0x2734 0x2735
        0x2744 0x2745 0x2746 0x2747 0x2748 0x2749 0x274A 0x274B
    )

    # Select a random index from the unicode_range array
    local index=$((RANDOM % ${#unicode_range[@]}))
    printf "\\U$(printf '%x' "${unicode_range[$index]}")"
}

# Function to create a 16x16 grid
create_grid() {
    # Generate both border and inner characters from the same set
    local border_char=$(random_graphical_char)  # Random border character
    local inner_char=$(random_graphical_char)   # Random inner character

    # Ensure the inner character is different from the border character
    while [ "$inner_char" == "$border_char" ]; do
        inner_char=$(random_graphical_char)
    done

    # Print the grid
    for ((i = 0; i < 16; i++)); do
        for ((j = 0; j < 16; j++)); do
            if ((i == 0 || i == 15 || j == 0 || j == 15)); then
                # Print border character
                printf "%s" "$border_char"
            else
                # Print inner character
                printf "%s" "$inner_char"
            fi
        done
        echo  # New line after each row
    done
}

# Main script execution
create_grid