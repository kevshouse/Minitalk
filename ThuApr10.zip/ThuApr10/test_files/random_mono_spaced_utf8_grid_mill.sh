#!/bin/bash

# Function to generate a random monospaced UTF-8 character from a specified range
random_monospaced_char() {
    # Define a range of monospaced Unicode characters (e.g., box-drawing characters)
    local unicode_range=(
        0x2500 0x2501 0x2502 0x2503 0x2504 0x2505 0x2506 0x2507
        0x2508 0x2509 0x250A 0x250B 0x250C 0x250D 0x250E 0x250F
        0x2510 0x2511 0x2512 0x2513 0x2514 0x2515 0x2516 0x2517
        0x2518 0x2519 0x251A 0x251B 0x251C 0x251D 0x251E 0x251F
        0x2520 0x2521 0x2522 0x2523 0x2524 0x2525 0x2526 0x2527
        0x2528 0x2529 0x252A 0x252B 0x252C 0x252D 0x252E 0x252F
        0x2530 0x2531 0x2532 0x2533 0x2534 0x2535 0x2536 0x2537
        0x2538 0x2539 0x253A 0x253B 0x253C 0x253D 0x253E 0x253F
    )

    # Select a random index from the unicode_range array
    local index=$((RANDOM % ${#unicode_range[@]}))
    printf "\\U$(printf '%x' "${unicode_range[$index]}")"
}

# Function to create a 16x16 grid
create_grid() {
    # Generate both border and inner characters from the same set
    local border_char=$(random_monospaced_char)  # Random border character
    local inner_char=$(random_monospaced_char)   # Random inner character

    # Ensure the inner character is different from the border character
    while [ "$inner_char" == "$border_char" ]; do
        inner_char=$(random_monospaced_char)
    done

    # Print the grid
    for ((i = 0; i < 16; i++)); do
        for ((j = 0; j < 16; j++)); do
            if ((i == 0 || i == 15 || j == 0 || j == 15)); then
                # Print border character
                printf "%s" "$border_char"
            else
                # Print inner character
                printf "%s" "$inner_char"
            fi
        done
        echo  # New line after each row
    done
}

# Main script execution
create_grid