// minitalk.h
#ifndef MINITALK_H
# define MINITALK_H

# include <unistd.h>
# include <signal.h>
# include <stdlib.h>
# include <time.h>
# include "./libft/includes/libft.h"

# define TIMEOUT_SEC 1
# define MAX_RETRIES 5
# define MAX_CLIENTS 10
# define INACTIVITY_TIMEOUT 10

// Function declaration
int	ft_isdigit_str(const char *str);

typedef struct s_state {
    int         server_pid;
    char        *message;
    int         current_bit;
    int         ack_received;  // ✅ Correct spelling
    int         retries;
} t_state;

typedef struct s_client {
    int         pid;
    char        buffer[5];
    int         bit_count;
    size_t      byte_count;
    size_t      expected_bytes;
    time_t      last_active;
    int		ack_sent;
} t_client;

#endif
