# Start the server and redirect output
./server >> server_output.txt 2>&1 &

# Get the server PID
server_pid=$!
echo $server_pid

# Start clients with a delay
for i in {1..6}; do  # Change {1..2} to the desired number of clients
    ./client "$server_pid" "$(cat test_file1.txt)" &
    sleep 0.1  # Delay of 0.1 seconds between client starts
done
kill $server_pid
