#!/bin/bash

# Configuration
test_dir="test-dir"  # Directory containing test text files
output_file="server_output.txt"  # File where server output will be captured
num_clients=1  # Set this variable for the bonus phase (1 or more clients)

# Function to start the server and capture its PID
start_server() {
    ./server > server_output.txt 2>&1 &  # Redirect stdout and stderr to a file
    pid=$!  # Capture the PID of the server
    sleep 1  # Wait for the server to start
    echo "Server started with PID: $pid"
}

# Function to stop the server
stop_server() {
    kill "$pid"
    echo "Server with PID $pid stopped."
}

# Function to run mandatory tests
run_mandatory_tests() {
    start_server

    # Initialize total character count
    total_input_chars=0

    # Process each test file in the test directory
    for test_file in "$test_dir"/*; do
        if [ -f "$test_file" ]; then
            # Count characters in the input file
            chars_in_file=$(wc -c < "$test_file")
            total_input_chars=$((total_input_chars + chars_in_file))

            # Send the file content to the server (assuming your client takes a PID and text input)
            ./client "$pid" < "$test_file"
        fi
    done

    # Wait for the server to finish processing (you may need to adjust this)
    wait "$pid"

    # Capture the server output
    cat server_output.txt > "$output_file"

    # Count characters in the server output
    chars_in_output=$(wc -c < "$output_file")

    # Compare character counts
    if [ "$chars_in_output" -eq "$total_input_chars" ]; then
        echo "Mandatory tests passed: Output matches input character count."
    else
        echo "Mandatory tests failed: Output does not match input character count."
    fi

    stop_server
}

# Function to run bonus tests
run_bonus_tests() {
    start_server

    # Initialize total character count
    total_input_chars=0
    client_pids=()

    # Start the specified number of clients
    for ((i = 0; i < num_clients; i++)); do
        ./client "$pid" &
        client_pids+=($!)  # Capture the PID of each client
    done

    # Print the client PIDs
    echo "Client PIDs: ${client_pids[@]}"

    # Process each test file in the test directory
    for test_file in "$test_dir"/*; do
        if [ -f "$test_file" ]; then
            # Count characters in the input file
            chars_in_file=$(wc -c < "$test_file")
            total_input_chars=$((total_input_chars + chars_in_file))

            # Send the file content to clients in a round-robin fashion
            for client_pid in "${client_pids[@]}"; do
                ./client "$client_pid" < "$test_file"
            done
        fi
    done

    # Wait for all clients to finish
    for client_pid in "${client_pids[@]}"; do
        wait "$client_pid"
    done

    # Capture the server output
    cat server_output.txt > "$output_file"

    # Count characters in the server output
    chars_in_output=$(wc -c < "$output_file")

    # Compare character counts
    if [ "$chars_in_output" -eq "$total_input_chars" ]; then
        echo "Bonus tests passed: Output matches input character count."
    else
        echo "Bonus tests failed: Output does not match input character count."
    fi

    stop_server
}

# Main script execution
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 [m|b]"
    echo "  m: Run mandatory tests"
    echo "  b: Run bonus tests"
    exit 1
fi

case "$1" in
    m)
 echo "Running mandatory tests..."
        run_mandatory_tests
        ;;
    b)
        echo "Running bonus tests..."
        run_bonus_tests
        ;;
    *)
        echo "Invalid option: $1"
        echo "Usage: $0 [m|b]"
        exit 1
        ;;
esac
