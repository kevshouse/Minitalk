#!/bin/bash

# Navigate to the parent directory of minitalk
cd ..

# Remove any existing dump file
rm -f project_dump.txt

# Use find to gather all relevant files in the minitalk directory
find ./minitalk -type f \( -name "*.c" -o -name "*.h" -o -name "Makefile" \) -exec sh -c 'echo "\n=== FILE: {} ===\n"; cat {}' \; >> project_dump.txt

# Optional: Add a newline at the end of the file
echo "" >> project_dump.txt

# Display a success message
echo "Project dump completed. Output saved to project_dump.txt"
