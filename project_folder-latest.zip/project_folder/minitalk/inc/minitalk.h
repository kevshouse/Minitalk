/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minitalk.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/19 17:26:03 by keanders          #+#    #+#             */
/*   Updated: 2025/04/19 17:26:13 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINITALK_H
# define MINITALK_H
# define _GNU_SOURCE
# define MY_SIG_BIT0 SIGUSR1
# define MY_SIG_BIT1 SIGUSR2

# include <signal.h>
# include <unistd.h>
# include <stdlib.h>
# include "libft.h"

#endif
