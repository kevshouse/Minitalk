/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putpid.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/18 17:29:03 by keanders          #+#    #+#             */
/*   Updated: 2025/04/18 18:23:48 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minitalk.h"
#include "../../inc/libft.h"

void	ft_putpid(int pid)
{
	int		i;
	char	buffer[12];

	if (pid == 0)
	{
		write(1, "0", 1);
		return ;
	}
	i = 0;
	while (pid > 0)
	{
		buffer[i++] = (pid % 10) + '0';
		pid /= 10;
	}
	while (--i >= 0)
		write(1, &buffer[i], 1);
}
