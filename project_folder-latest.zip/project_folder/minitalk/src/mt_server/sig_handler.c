/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sig_handler.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/18 17:51:43 by keanders          #+#    #+#             */
/*   Updated: 2025/04/19 17:21:58 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/minitalk.h"
#include "sig_handler.h"

void	write_byte(char *c, int *bit_count, int *end_reached)
{
	if (*bit_count == 8)
	{
		if (*c != 0)
			write(1, c, 1);
		else
		{
			write(1, "\n", 1);
			*end_reached = 1;
		}
		*c = 0;
		*bit_count = 0;
	}
}

void	sig_handler(int sig, siginfo_t *info, void *context)
{
	static pid_t	client_pid = 0;
	static int		bit_count = 0;
	static char		c = 0;
	int				end_reached;

	(void)context;
	end_reached = 0;
	if (client_pid == 0)
		client_pid = info->si_pid;
	if (client_pid != info->si_pid)
		return ;
	c |= (sig == MY_SIG_BIT1) << (7 - bit_count);
	bit_count++;
	if (bit_count == 8)
	{
		write_byte(&c, &bit_count, &end_reached);
	}
	usleep(50);
	kill(client_pid, MY_SIG_BIT0);
	if (end_reached)
		client_pid = 0;
}
