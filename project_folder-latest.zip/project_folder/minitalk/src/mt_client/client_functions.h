/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client_functions.h                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/17 18:46:09 by keanders          #+#    #+#             */
/*   Updated: 2025/04/19 17:26:00 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CLIENT_FUNCTIONS_H
# define CLIENT_FUNCTIONS_H

# include "minitalk.h"

void	ack_handler(int sig);
void	tx_bit(int server_pid, int bit);
void	tx_char(int server_pid, char c);
void	send_signal(int server_pid, int bit);
#endif
