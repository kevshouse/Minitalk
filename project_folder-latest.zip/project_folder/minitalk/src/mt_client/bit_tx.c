/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bit_tx.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/17 18:45:55 by keanders          #+#    #+#             */
/*   Updated: 2025/04/19 18:17:45 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/minitalk.h"
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

void send_signal(int server_pid, int bit);
void wait_for_ack(void);

volatile sig_atomic_t	g_ack_received = 0;

void	ack_handler(int sig)
{
	(void)sig;
	g_ack_received = 1;
}

void	send_signal(int server_pid, int bit)
{
	if (bit)
	{
		if (kill(server_pid, SIGUSR2) < 0)
		{
			write(STDERR_FILENO,
				"Error: Sig transmission failed\n", 31);
			exit(EXIT_FAILURE);
		}
	}
	else
	{
		if (kill(server_pid, SIGUSR1) < 0)
		{
			write(STDERR_FILENO,
				"Error: Sig transmission failed\n", 31);
			exit(EXIT_FAILURE);
		}
	}
}

void	wait_for_ack(void)
{
	while (!g_ack_received)
	{
		usleep(100);
	}
}

void tx_bit(int server_pid, int bit)
{
	g_ack_received = 0;
	send_signal(server_pid, bit);
	wait_for_ack();
}
