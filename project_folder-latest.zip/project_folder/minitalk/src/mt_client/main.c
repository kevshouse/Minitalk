/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/18 18:07:26 by keanders          #+#    #+#             */
/*   Updated: 2025/04/18 18:07:35 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../mt_client/client_functions.h" 

int	main(int argc, char *argv[])
{
	int					server_pid;
	struct sigaction	sa;
	int					i;

	if (argc != 3)
	{
		write(2, "Usage: ", 7);
		write(2, argv[0], ft_strlen(argv[0]));
		write(2, " <server_pid> <string_to_send>\n", 31);
		return (1);
	}
	server_pid = ft_atoi(argv[1]);
	sa.sa_handler = ack_handler;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = 0;
	sigaction(SIGUSR1, &sa, NULL);
	i = 0;
	while (argv[2][i] != '\0')
	{
		tx_char(server_pid, argv[2][i]);
		i++;
	}
	tx_char(server_pid, '\0');
	return (0);
}
