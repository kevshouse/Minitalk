#include "../minitalk.h"
#include "sig_handler.h"
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

void sig_handler(int sig, siginfo_t *info, void *context) {
    (void)context; // Explicitly mark 'context' as unused

    static pid_t client_pid = 0;
    static int bit_count = 0;
    static char c = 0;

    // Initialize client_pid on first signal
    if (client_pid == 0) {
        client_pid = info->si_pid;
    }

    // Check if the signal is from the expected client
    if (client_pid != info->si_pid) {
        return; // Ignore signals from other clients
    }

    // Accumulate the bit, starting from LSB
    c |= (sig == MY_SIG_BIT1) << (7 - bit_count);
    bit_count++;

    // If we have received 8 bits, print the character
    if (bit_count == 8) {
        if (c) {
            write(1, &c, 1); // Print the character to stdout
        } else {
            write(1, "\n", 1); // Print a newline for null character
        }
        // Reset for the next character
        bit_count = 0;
        c = 0;
    }

    // Send acknowledgment back to the client
    usleep(50); // Small delay to avoid busy waiting
    kill(client_pid, MY_SIG_BIT0); // Acknowledge receipt of the bit
}
