/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/16 12:52:28 by keanders          #+#    #+#             */
/*   Updated: 2025/04/16 22:57:13 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "../minitalk.h" // Include the main header file
#include "sig_handler.h" // Include the signal handler header

int main(void)
{
    struct sigaction sa;

    // Set up the signal handler
    sa.sa_sigaction = sig_handler; // Use the signal handler function from sig_handler.c
    sa.sa_flags = SA_SIGINFO | SA_NODEFER; // Use SA_SIGINFO to get additional info
    sigemptyset(&sa.sa_mask); // Initialize the signal set to empty

    // Register the signal handlers for SIGUSR1 and SIGUSR2
    if (sigaction(MY_SIG_BIT0, &sa, NULL) < 0)
    {
        perror("sigaction failed for SIGUSR1");
        exit(EXIT_FAILURE);
    }

    if (sigaction(MY_SIG_BIT1, &sa, NULL) < 0)
    {
        perror("sigaction failed for SIGUSR2");
        exit(EXIT_FAILURE);
    }

    // Print the server's PID
    printf("Server PID: %d\n", getpid());

    // Infinite loop to keep the server running and waiting for signals
    while (1)
    {
        pause(); // Wait for signals
    }

    return (0); // Exit successfully (though this line will never be reached)
}
