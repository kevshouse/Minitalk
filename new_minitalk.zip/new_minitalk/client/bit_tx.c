
// client/bit_tx.c
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

volatile sig_atomic_t g_ack_received = 0; // Global variable to track acknowledgment

// Acknowledgment signal handler
void ack_handler(int sig)
{
    (void)sig; // Explicitly mark 'sig' as unused
    g_ack_received = 1; // Set acknowledgment received flag
}
// Function to send (tx for transmit) a single bit to the server
void tx_bit(int server_pid, int bit)
{
    if (bit == 1)
    {
        kill(server_pid, SIGUSR2); // Send bit 1
    } else
    {
        kill(server_pid, SIGUSR1); // Send bit 0
    }

    // Wait for acknowledgment
    g_ack_received = 0; // Reset acknowledgment flag
    while (!g_ack_received)
    {
        usleep(100); // Sleep briefly to avoid busy waiting
    }
}

// Function to send a character to the server
void tx_char(int server_pid, char c)
{
    int     i;
    int     bit;

    i = 7;
    while(i >= 0)
    {
        bit = (c >> i)&1;// Extract the bit
        tx_bit(server_pid, bit);
        i--;
    }
}
