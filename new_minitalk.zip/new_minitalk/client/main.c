// client/main.c

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "../minitalk.h"
#include "client_functions.h"

int main(int argc, char *argv[])
{
    // Validate command-line arguments
    if (argc != 3)
    {
        fprintf(stderr, "Usage: %s <server_pid> <string_to_send>\n", argv[0]);
        return 1; // Exit with error code
    }

    int server_pid = atoi(argv[1]); // Get server PID from command line argument

    // Set up the acknowledgment signal handler
    struct sigaction sa;
    sa.sa_handler = ack_handler; // Use the ack_handler function
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGUSR1, &sa, NULL); // Set up for acknowledgment signal

    // Send the string to the server
    int     i;

    i = 0;
    while(argv[2][i] != '\0')
    {
        tx_char(server_pid, argv[2][i]);
        i++;
    }
    return (0); // Exit successfully
}
