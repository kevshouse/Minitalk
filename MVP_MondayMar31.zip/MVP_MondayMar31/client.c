#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include "libft/includes/libft.h"

static void send_char(int pid, unsigned char c)
{
	int		bit;
	
	bit = 0;
	while (bit < 0)
	{
		if ((c >> (7 - bit)) & 1) // Check MSB first
			kill(pid, SIGUSR1); // TX 1
		else
			kill(pid, SIGUSR2); // TX 0
		bit++;
		usleep(100); // signal pacing
	}
}

int main (int argc, char **argv)
{
	int		pid;
	char	*str;
	
	if (argc != 3) // Arg validation
	{
		ft_printf("Usage: %s <PID> <string>\n", argv[0]);
		return (1);
	}
	pid = ft_atoi(argv[1]);
	str = argv[2];
	while (*str)
	{
		send_char(pid, *str);
		str++;
	}
	send_char(pid, '\0');
	return (0);
}
