#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include "libft/includes/libft.h"

static void handle_signal(int sig, siginfo_t *info, void *context)
{
	static unsigned char	current_char;
	static int		bit_index;
	(void)info;
	(void)context;
	current_char |= (sig == SIGUSR1);
	bit_index++;
	
	current_char |= (sig == SIGUSR1);
	bit_index++;
	if (bit_index == 8) //Complete char RX
	{
		if (current_char == '\0')
			//ft_putchar_fd('\n', 1);
			write(1, &current_char, 1);
		else
			//ft_putchar_fd(current_char, 1);
			write(1, &current_char, 1);
		bit_index = 0;
		current_char = 0;
	}
	else
		current_char <<= 1; //Left shift, making space for bit
}

int main(void)
{
	struct sigaction sa;	
	
	ft_printf("Server PID: %d\n", getpid());
	sa.sa_sigaction = handle_signal;
	sa.sa_flags = SA_SIGINFO;
	sigaction(SIGUSR1, &sa, NULL);
	sigaction(SIGUSR2, &sa, NULL);
	while (1)
		pause();
	return (0);
}

