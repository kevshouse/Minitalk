#!/bin/bash

# Function to generate a random ASCII character
random_ascii_char() {
    # Generate a random ASCII character from the printable range (32 to 126)
    local ascii_code=$((RANDOM % 95 + 32))  # 95 printable ASCII characters
    printf "\\$(printf '%03o' "$ascii_code")"
}

# Function to create an ASCII grid pattern with a border
create_ascii_grid_with_border() {
    local rows=$1
    local cols=$2

    # Generate a border character
    local border_char=$(random_ascii_char)

    # Print the top border
    for ((j = 0; j < cols + 2; j++)); do
        printf "%s" "$border_char"
    done
    echo  # New line after the top border

    # Print the grid with borders
    for ((i = 0; i < rows; i++)); do
        printf "%s" "$border_char"  # Left border
        for ((j = 0; j < cols; j++)); do
            # Print a random ASCII character
            printf "%s" "$(random_ascii_char)"
        done
        printf "%s" "$border_char"  # Right border
        echo  # New line after each row
    done

    # Print the bottom border
    for ((j = 0; j < cols + 2; j++)); do
        printf "%s" "$border_char"
    done
    echo  # New line after the bottom border
}

# Main script execution
# Set the desired grid size
rows=16  # Number of rows
cols=32  # Number of columns

create_ascii_grid_with_border "$rows" "$cols"
