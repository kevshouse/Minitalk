#include "../../inc/minitalk.h"
#include <signal.h>
#include <unistd.h>

static void	sig_handler(int sig, siginfo_t *info, void *context)
{
	static int	bit_count;
	static char	c;
	static pid_t	client_pid;

	(void)context;
	if (!client_pid)
		client_pid = info->si_pid;
	if (client_pid != info->si_pid)
		return;
	c |= (sig == MY_SIG_BIT1) << bit_count; // Updated
	bit_count++;
	if (bit_count == 8)
	{
		if (c)
			write(1, &c, 1);
		else
			write(1, "\n", 1);
		bit_count = 0;
		c = 0;
	}
	usleep(50);
	kill(client_pid, MY_SIG_BIT0); // Updated
}

int	main(void)
{
	struct sigaction	sa;

	sa.sa_sigaction = sig_handler;
	sa.sa_flags = SA_SIGINFO | SA_NODEFER;
	sigemptyset(&sa.sa_mask);
	sigaction(MY_SIG_BIT0, &sa, NULL); // Updated
	sigaction(MY_SIG_BIT1, &sa, NULL); // Updated
	ft_putstr_fd("Server PID: ", STDOUT_FILENO);
	ft_putnbr_fd(getpid(), STDOUT_FILENO);
	ft_putstr_fd("\n", STDOUT_FILENO);
	while (1)
		pause();
	return (0);
}
