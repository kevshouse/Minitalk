// Error handling functions
/**
 * @brief Safe wrapper for kill() system call
 * @param pid Target process ID
 * @param sig Signal to send
 * @return 0 on success, -1 on error (logs details)
 * @note Mandatory for rror handling
*/
#include "../../inc/minitalk.h"
