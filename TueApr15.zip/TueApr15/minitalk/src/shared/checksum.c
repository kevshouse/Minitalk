// XOR validation (bonus)
#include "../../inc/minitalk.h"

uint8_t calculate_checksum(const char *str)// uses bitwise OR
{
    uint8_t sum = 0;

    while (*str)
        sum ^= *str++;
    return (sum);
}
