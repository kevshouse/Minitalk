/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   safe_kill.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/14 14:39:17 by keanders          #+#    #+#             */
/*   Updated: 2025/04/14 14:42:10 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Safe wrapper for kill() system call
 * @param pid Target process ID
 * @param sig Signal to send
 * @return 0 on success, -1 on error (logs details)
 * @note Mandatory for error handling
 */

// #include "../../inc/minitalk.h"

int	safe_kill(pid_t pid, int sig)
{
	if (kill(pid, sig)== -1)
	{
	   write(2, "Error: kill failed\n", 19);
       return (-1);
	}
	return (0);
}
