// Bit encoding/decoding
#include "../../inc/minitalk.h"

static volatile sig_atomic_t g_ack_status = ACK_PENDING;
