// Message encoding logic
// handles what to send
#include "../../inc/minitalk.h"

static int  g_bit_pos;

void    encode_char(char c, int *signals)
{
    int i;

    i = 0;
    while (i < 8)
    {
        if ((c & (1 << i)) != 0)
            signals[g_bit_pos] = SIG_BIT1;
        else
            signals[g_bit_pos] = SIG_BIT0;
        g_bit_pos++;
        if (g_bit_pos >= BUFFER_SIZE)
            g_bit_pos = 0;
        i++;
    }
}

/* Example usage with state */
void    transmit_message(t_client_state *state)
{
    int signals[BUFFER_SIZE];
    int i;

    i = 0;
    while (state->message[i])
    {
        encode_char(state->message[i], signals);
        i++;
    }
    // Add send_bit loop here
}
