// PID validation & state setup
