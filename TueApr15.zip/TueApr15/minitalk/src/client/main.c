#include "../../inc/minitalk.h"
#include "../../inc/client_functions.h"
#include <signal.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <limits.h>

static volatile sig_atomic_t	g_ack_received;

/*static void	ack_handler(int sig)
{
	(void)sig;
	g_ack_received = 1;
	}*/

/*static void	send_bit(pid_t pid, int bit)
{
	int	signal;
	int	retries;

	retries = 0;
	signal = bit ? MY_SIG_BIT1 : MY_SIG_BIT0;
	while (retries < MAX_RETRIES)
	{
		g_ack_received = 0;
		if (kill(pid, signal) == -1)static void	ack_handler(int sig)

		{
			ft_putstr_fd("Error: kill() failed - ", STDERR_FILENO);
			ft_putstr_fd(strerror(errno), STDERR_FILENO);
			ft_putstr_fd("\n", STDERR_FILENO);
			exit(EXIT_FAILURE);
		}
		while (!g_ack_received && retries < MAX_RETRIES)
		{
			usleep(ACK_DELAY_US * (retries + 1));
			retries++;
		}
		if (g_ack_received)
			break ;
	}
	if (retries >= MAX_RETRIES)
	{
		ft_putstr_fd("Error: No ACK received\n", STDERR_FILENO);
		exit(EXIT_FAILURE);
	}
	}*/

/*static void	send_char(pid_t pid, char c)
{
	int	i;

	i = 0;
	while (i < 8)
	{
		send_bit(pid, (c >> i) & 1);
		i++;
	}
	}*/

int	main(int argc, char **argv)
{
	struct sigaction	sa;
	pid_t				pid;
	char				*message;

	if (argc != 3)
	{
		ft_putstr_fd("Usage: ./client <PID> <message>\n", STDERR_FILENO);
		exit(EXIT_FAILURE);
	}
	pid = ft_atoi_validate(argv[1]);
	if (pid <= 0)
	{
		ft_putstr_fd("Error: Invalid PID\n", STDERR_FILENO);
		exit(EXIT_FAILURE);
	}
	sa.sa_handler = ack_handler;
	sa.sa_flags = 0;
	sigemptyset(&sa.sa_mask);
	sigaction(MY_SIG_BIT0, &sa, NULL);
	message = argv[2];
	while (*message)
		send_char(pid, *message++);
	send_char(pid, '\0');
	return (EXIT_SUCCESS);
}
