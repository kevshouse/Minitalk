
#include "../../inc/minitalk.h"
#include "../../inc/client_functions.h"

static volatile sig_atomic_t g_ack_received;

void ack_handler(int sig) {
    (void)sig;
    g_ack_received = 1;
}

void send_bit(pid_t pid, int bit) {
    int signal;
    int retries;

    retries = 0;
    signal = bit ? MY_SIG_BIT1 : MY_SIG_BIT0;
    while (retries < MAX_RETRIES) {
        g_ack_received = 0;
        if (kill(pid, signal) == -1) {
            ft_putstr_fd("Error: kill() failed - ", STDERR_FILENO);
            exit(EXIT_FAILURE);
        }
        while (!g_ack_received && retries < MAX_RETRIES) {
            usleep(ACK_DELAY_US * (retries + 1));
            retries++;
        }
        if (g_ack_received)
            break;
    }
    if (retries >= MAX_RETRIES) {
        ft_putstr_fd("Error: No ACK received\n", STDERR_FILENO);
        exit(EXIT_FAILURE);
    }
}

void send_char(pid_t pid, char c) {
    int i;

    i = 0;
    while (i < 8) {
        send_bit(pid, (c >> i) & 1);
        i++;
    }
}
