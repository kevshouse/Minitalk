#ifndef MINITALK_H
# define MINITALK_H

# include <unistd.h>
# include <signal.h>
# include <stdlib.h>
# include <stdint.h>
#include <string.h>  // Add for strerror()
#include <limits.h> // Add for INT_MAX

# define MY_SIG_BIT0 SIGUSR1  // Renamed to avoid conflict
# define MY_SIG_BIT1 SIGUSR2  // Renamed to avoid conflict
# define BUFFER_SIZE 1024
# define MAX_RETRIES 10
# define ACK_DELAY_US 1000
# define CLIENT_TIMEOUT 5

int		ft_atoi_validate(const char *str);
int		ft_isdigit(int c);
int		ft_isspace(int c);
void	ft_putchar_fd(char c, int fd);
void	ft_putstr_fd(char *str, int fd);
void	ft_putnbr_fd(int n, int fd);


typedef struct s_client {
	pid_t		pid;
	size_t		bit_count;
	uint8_t		checksum;
	char		buffer[BUFFER_SIZE];
}	t_client;

#endif
