#ifndef CLIENT_FUNCTIONS_H
#define CLIENT_FUNCTIONS_H

#include <signal.h>
#include <stdlib.h>

void ack_handler(int sig);
void send_bit(pid_t pid, int bit);
void send_char(pid_t pid, char c);

#endif // CLIENT_FUNCTIONS_H
