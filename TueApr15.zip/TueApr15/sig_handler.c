/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   server.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/07 16:11:39 by keanders          #+#    #+#             */
/*   Updated: 2025/04/08 12:55:00 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include "minitalk.h"
#define MAX_UTF8_BYTES 4  // Maximum bytes for a UTF-8 character


static volatile	sig_atomic_t	g_received_bits[MAX_UTF8_BYTES];
static volatile sig_atomic_t g_received_bytes[MAX_UTF8_BYTES];
static int g_bit_count = 0;
static int g_byte_count = 0;
static int g_expected_bytes = 0;  // Number of expected bytes for the current character

//    Sig Handler Function Model

void sig_handler(int sig)
{
    if (sig == SIGUSR1)
    {
        g_received_bytes[g_byte_count] |= (1 << g_bit_count);  // Set the bit
    }
    g_bit_count++;

    // Check if we have received enough bits for a byte
    if (g_bit_count == 8)
        {
            g_bit_count = 0;  // Reset bit count
            g_byte_count++;

            // Determine the expected number of bytes for the UTF-8 character
            if (g_byte_count == 1)
            {  // First byte received
                unsigned char first_byte = g_received_bytes[0];
                g_expected_bytes = get_expected_utf8_bytes(first_byte);
                if (g_expected_bytes == -1)
                {
                    // Handle invalid UTF-8 start byte
                    g_byte_count = 0;  // Reset for next character
                    return;
                }
            }
        }

        // Check if we have received all bytes for the UTF-8 character
        if (g_byte_count == g_expected_bytes)
        {
            process_utf8_character();  // Process the complete character
        }
    }
}
