// minitalk.h
#ifndef MINITALK_H
# define MINITALK_H

# include <unistd.h>
# include <signal.h>
# include <stdlib.h>
# include <time.h>
# include "./libft/includes/libft.h"

# define TIMEOUT_SEC 1
# define MAX_RETRIES 5
# define MAX_CLIENTS 10
# define INACTIVITY_TIMEOUT 10

// Function declaration
int	ft_isdigit_str(const char *str);

typedef struct s_state {
    int         server_pid;
    char        *message;
    int         current_bit;
    int         ack_received;  // ✅ Correct spelling
    int         retries;
} t_state;

typedef struct s_client {
    int         pid;
    char        buffer[5];
    int         bit_count;
    size_t      byte_count;
    size_t      expected_bytes;
    time_t      last_active;
} t_client;

// Siganls:
void	setup_signal_handlers(struct sigaction *sa, void (*handler)(int));
void	send_bit(pid_t pid, char bit);
void	await_confirmation(void);

// Bitwise Comms
void	encode_char_to_bits(char c, pid_t pid);
char	decode_bits_to_char(int *received_bits);
void	reset_bit_counter(void);

g_received_bytes[g_byte_count]

// Error Handlers
void	validate_pid(pid_t pid);
void	check_kill_error(pid_t pid);
void	fatal_error(const char *msg);
#endif
