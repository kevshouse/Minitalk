// Function Snippets
//--------------------------------------//
//      Server-side circular buffer
# define BUF_SIZE 1024 // place this in the header file
static char	g_buffer[BUF_SIZE];
static int		g_buf_pos;

g_buf_pos = 0;
void	buffer(char c)
{
	if (g_buf_pos >= BUF_SIZE - 1) flush_buffer();
	g_buffer[g_buf_pos++] = c;
}

//--------------------------------------//

//--------------------------------------//

//    Sig Handler Function Model
# define MAX_UTF8_BYTES 4 // MAximum size of a UTF-8 character
static volatile	sig_atomic_t	g_received_bits[MAX_UTF_BYTES];
static int		g_bit_count = 0; //Remember norminette!
static int		g_byte_count = 0;

void	sig_handler(int sig)
{
	if (sig == SIGUSR1)
	{
		g_received_bits[g_byte_count] | = (1 << g_bit_count);  // Set the bit
	}
	g_bit_count++;
	// Check if we have received enough bits for a UTF-8 character
	if (g_bit_count == 8)
	{
		g_bit_count = 0; //reset bit count
		g_byte_count++;
		
	}
	// Check if we have received all bytes for the UTF-8 character
	if (g_byte_count == MAX_UTF8_BYTES ||/* condition to check end of character */) //Not complete yet!
	{
		// PRocess the complete UTF-8 char
		// Reset ready for next char
		g_byte_count = 0;
		memset(g_received_bits, 0, sizeof(g_received_bits));
	}
}


	received_char |= (sig == SIGUSR1) << bit_count++;
//--------------------------------------//

/* Detect UTF-8 character types 
	'0xxxxxxx' (1 byte) (ASCII) - No bytes follow
	'110xxxxx 10xxxxxx' (2 bytes) Lefthand pattern = 110, 1 byte to follow.
	'1110xxxx 10xxxxxx 10xxxxxx (3 bytes)' Lefthand pattern = 1110 = two additional bytes follow.
	'11110xxx 10xxxxxx 10xxxxxx 10xxxxxx (4 bytes)
The first byte starts with 11110, indicating three additional bytes follow.'
	
*/	
	
#include <stdint.h>

int get_expected_utf8_bytes(uint8_t first_byte)
{
	if ((first_byte & 0x80) == 0)
		return (1);  // 1 byte character
	else if ((first_byte & 0xE0) == 0xC0)
		return (2);  // 2 byte character
	else if ((first_byte & 0xF0) == 0xE0)
		return (3);  // 3 byte character
	else if ((first_byte & 0xF8) == 0xF0)
		return (4);  // 4 byte character
	else
		return (-1);  // Invalid UTF-8 start byte
}
//--------------------------------------//

//----- signal handler -----------------//

#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define MAX_UTF8_BYTES 4  // Maximum bytes for a UTF-8 character

static volatile sig_atomic_t g_received_bytes[MAX_UTF8_BYTES];
static int g_bit_count = 0;
static int g_byte_count = 0;
static int g_expected_bytes = 0;  // Number of expected bytes for the current character

void process_utf8_character() {
    // Convert received bytes to a character
    char utf8_char[MAX_UTF8_BYTES + 1];  // +1 for null terminator
    int byte_length = g_byte_count;  // Number of bytes received

    // Copy received bytes into the utf8_char array
    for (int i = 0; i < byte_length; i++) {
        utf8_char[i] = g_received_bytes[i];
    }
    utf8_char[byte_length] = '\0';  // Null-terminate the string

    // Print or process the complete UTF-8 character
    printf("Received UTF-8 character: %s\n", utf8_char);

    // Reset for the next character
    g_byte_count = 0;
    g_expected_bytes = 0;  // Reset expected bytes
    memset(g_received_bytes, 0, sizeof(g_received_bytes));
}

void sig_handler(int sig) {
    if (sig == SIGUSR1) {
        g_received_bytes[g_byte_count] |= (1 << g_bit_count);  // Set the bit
    }
    g_bit_count++;

    // Check if we have received enough bits for a byte
    if (g_bit_count == 8) {
        g_bit_count = 0;  // Reset bit count
        g_byte_count++;

        // Determine the expected number of bytes for the UTF-8 character
        if (g_byte_count == 1) {  // First byte received
            unsigned char first_byte = g_received_bytes[0];
            g_expected_bytes = get_expected_utf8_bytes(first_byte);
            if (g_expected_bytes == -1) {
                // Handle invalid UTF-8 start byte
                g_byte_count = 0;  // Reset for next character
                return;
            }
        }

        // Check if we have received all bytes for the UTF-8 character
        if (g_byte_count == g_expected_bytes) {
            process_utf8_character();  // Process the complete character
        }
    }
}
//----- signal handler -----------------//

