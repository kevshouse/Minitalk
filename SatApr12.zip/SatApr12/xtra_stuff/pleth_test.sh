#!/bin/bash

./server > server_output.txt &
sleep 1

SERVER_PID=$(head -n 1 server_output.txt)
TEXT_DIR="./test_files"

for file in "TEXT_DIR"/*; do
	CONTENT="$(<"$file")"
	./client $SERVER_PID "CONTENT" &
done
wait
