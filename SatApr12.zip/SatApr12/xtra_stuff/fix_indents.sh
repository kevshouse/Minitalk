# fix_indents.sh

#!/bin/sh

# Check for correct usage
if [ $# -ne 1 ]; then
    echo "Usage: $0 <file.c>"
    exit 1
fi

# Validate file existence
if [ ! -f "$1" ]; then
    echo "Error: File $1 not found."
    exit 1
fi

# Create temporary file
tmpfile=$(mktemp)

# Process file using awk
awk -v trigger="/* ************************************************************************** */" '
BEGIN { found = 0 }
{
    if (!found && $0 == trigger) {
        found = 1
        print
        next
    }
    if (found) {
        gsub(/    /, "\t")
    }
    print
}
' "$1" > "$tmpfile" && mv "$tmpfile" "$1"

# Cleanup temporary file
rm -f "$tmpfile"
