#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include "libft.h"  // Ensure this is included

#define TIMEOUT_SEC 1
#define MAX_RETRIES 5

// Function declaration if not already in libft.h
int ft_isdigit_str(const char *str) {
    while (*str) {
        if (!ft_isdigit(*str)) {
            return 0; // Return false if any character is not a digit
        }
        str++;
    }
    return 1; // Return true if all characters are digits
}

typedef struct s_state {
    int         server_pid;
    char        *message;
    int         current_bit;
    int         ack_received;
    int         retries;
} t_state;

static t_state g_state;

// Timeout Handler
void handle_timeout(int sig) {
    (void)sig;
    if (g_state.retries++ < MAX_RETRIES && !g_state.ack_received) {
        kill(g_state.server_pid, 
            (g_state.message[0] & (1 << (7 - g_state.current_bit)) ? SIGUSR2 : SIGUSR1));
        alarm(TIMEOUT_SEC);
    } else {
        ft_putstr_fd("Error: Server unresponsive\n", 2);
        exit(EXIT_FAILURE);
    }
}

// ACK Handler
void handle_ack(int sig, siginfo_t *info, void *context) {
    (void)sig;
    (void)context;
    if (info->si_pid == g_state.server_pid) {
        g_state.ack_received = 1;
        alarm(0); // Disable timeout
    }
}

// Send single bit with retry logic
void send_bit(void) {
    g_state.ack_received = 0;
    g_state.retries = 0;
    int bit = (g_state.message[0] & (1 << (7 - g_state.current_bit))) ? 1 : 0;
    kill(g_state.server_pid, bit ? SIGUSR2 : SIGUSR1);
    alarm(TIMEOUT_SEC);
    while (!g_state.ack_received)
        pause();
    g_state.current_bit++;
}

// Send full message
void send_message(void) {
    while (*g_state.message) {
        g_state.current_bit = 0;
        while (g_state.current_bit < 8)
            send_bit();
        g_state.message++;
    }
}

int main(int argc, char **argv) {
    if (argc != 3 || !ft_isdigit_str(argv[1])) {
        ft_putstr_fd("Usage: ./client [server-pid] [message]\n", 2);
        return 1;
    }

    struct sigaction sa_ack = {0};
    sa_ack.sa_sigaction = handle_ack;
    sa_ack.sa_flags = SA_SIGINFO;
    sigaction(SIGUSR1, &sa_ack, NULL);

    signal(SIGALRM, handle_timeout);

    g_state = (t_state){.server_pid = ft_atoi(argv[1]), 
                       .message = argv[2]};
    send_message();
    return 0;
}
