/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/07 16:11:56 by keanders          #+#    #+#             */
/*   Updated: 2025/04/08 12:16:49 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
If You Want to Read from stdin
Modify your client code to read input from stdin instead of argv[2]. Example changes:

c
Run
Copy code
// In client.c, replace:
g_state.message = argv[2];

// With:
char *message = ft_strdup(get_next_line(STDIN_FILENO));
g_state.message = message;
Then use:

bash
Run
Copy code
./client 775621 < emoji.txt

*/
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include "minitalk.h"

#define TIMEOUT_SEC 1
#define MAX_RETRIES 5

//static		t_state g_state;

//g_state.current_bit = 0;
//g_state.ack_receaved = 0;
//g_state.retries = 0;

int	ft_isdigit_str(const char *str);

static t_state g_state =
{
	.server_pid = 0,
	.message = NULL,
	.current_bit = 0,
	.ack_received = 0,
	.retries = 0,
};


// Timeout Handler
void	handle_timeout(int sig)
{
	int		signal_to_send;
	
	signal_to_send = SIGUSR1;
	(void)sig;
	if (g_state.retries++ < MAX_RETRIES && !g_state.ack_received) {
        if (g_state.message[0] & (1 << (7 - g_state.current_bit)))
            signal_to_send = SIGUSR2;
        else
            signal_to_send = SIGUSR1;
        kill(g_state.server_pid, signal_to_send);
        alarm(TIMEOUT_SEC);
    } else {
        ft_putstr_fd("Error: Server not responding\n", 2);
        exit(1);
    }
	kill(g_state.server_pid, signal_to_send);
	alarm(TIMEOUT_SEC);
}

// ACK Handler
void	handle_ack(int sig, siginfo_t *info, void *context)
{
	(void)sig;
	(void)context;
	if (info->si_pid == g_state.server_pid)
	{
		g_state.ack_received = 1;
		alarm(0);
	}
}

void send_bit(void)
{
    int bit;

    if (!g_state.message || !*g_state.message) return;
    
    g_state.ack_received = 0;
    g_state.retries = 0;
    bit = g_state.message[0] & (1 << (7 - g_state.current_bit));
    kill(g_state.server_pid, bit ? SIGUSR2 : SIGUSR1);
    
    alarm(TIMEOUT_SEC);
    while (!g_state.ack_received)
        pause();
    alarm(0);
    
    g_state.current_bit++;
}

// Send full message
void	send_message(void)
{
	while (*g_state.message)
	{
		g_state.current_bit = 0;
		while (g_state.current_bit < 8)
			send_bit();
		g_state.message++;
	}
}

int main(int argc, char **argv)
{
	struct sigaction sa_ack;

	if (argc != 3 || !ft_isdigit_str(argv[1]))
	{
		ft_putstr_fd("Usage: ./client [server-pid] [message]\n", 2);
		return (1);
	}
	    
    // Proper struct initialization
	ft_memset(&sa_ack, 0, sizeof(sa_ack));  // Correctly zero out the struct
	sa_ack.sa_sigaction = handle_ack;  // Set the signal handler
	sa_ack.sa_flags = SA_SIGINFO;  // Set the flags
    	sigaction(SIGUSR1, &sa_ack, NULL);  // Register the signal handler
	signal(SIGALRM, handle_timeout);  // Set the timeout handler
    	g_state.server_pid = ft_atoi(argv[1]);
	g_state.message = argv[2];
    
	send_message();
	return (0);
}
