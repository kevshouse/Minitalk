# include <time.h>

static t_client *get_client(int pid)
{
	int		i;
		
	i = 0;
	// 1st passs: Checking for existing client of empty slot
	while(i < MAX_CLIENTS)
	{
		if (g_clients[i].pid == pid)
			return (&g_clients[i]); // Exisint Client
		if (g_clients[i].pid == 0)
		{
			ft_memset(&g_clients[i], 0, sizeof(t_client));
			g_clients[i].pid = pid;
			// init time_samp
			g_clients[i].last_active = time(NULL);
			return (&g_clients[i]);
		}
		i++;		
	}
	
	//Second Pass: Clean inactive clients if no slots are found
	time_t current_time = time(NULL);
	i = 0;
	while (i < MAX_CLIENTS)
	{
		// CLient inactive? (No siganl for 10 seconds)
		if (difftime(current_time, g_clients[i].last_active > 10)
		{	
			// Reset slot
			ft_memset(&g_clients[i], 0, sizeof(t_client));
			g_clients[i].pid = pid; // Assign new client 
			g_clients[i].last_active = time(NULL);
			return (&g_clients[i]);
		}
		i++;
	}
	return (NULL); // All slots full and active
}
