/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit_str.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: keanders <keanders@student.42london.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 16:03:38 by keanders          #+#    #+#             */
/*   Updated: 2025/04/08 16:11:01 by keanders         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// ft_isdigit_str.c
/*
This funtion is a wrapper to ft_isdigit(int c).
The function returns true if all the chars pointed to by *str are
are digits.

*/
#include "./libft/includes/libft.h"

int	ft_isdigit_str(const char *str)
{
	while (*str)
	{
		if (!ft_isdigit(*str))
			return (0);
		str++;
	}
	return (1);
}
