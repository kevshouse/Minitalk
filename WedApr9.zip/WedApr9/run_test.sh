#!/bin/bash

# Start the server in the background and capture its PID
./server &

# Get the PID of the last background process (the server)
pid=$!

# Wait a moment to ensure the server has started and echoed its PID
sleep 1

# Check if the server is running
if ! kill -0 "$pid" 2>/dev/null; then
    echo "Server failed to start."
    exit 1
fi

# Specify the text file
text_file="emoji.txt"

# Check if the text file exists
if [ ! -f "$text_file" ]; then
    echo "Text file not found."
    exit 1
fi

# Read the text from the file
text_input=$(<"$text_file")

# Call your application with the PID and text input
./client "$pid" "$text_input"

# Optionally, you can stop the server after processing
kill "$pid"
