#!/bin/bash

# Function to create a bordered grid for a single character
create_character_grid() {
    local char=$1
    local border_char="-"
    local side_border="|"
    local grid_size=16  # Number of rows and columns

    # Create the repeated character string
    local repeated_char="${char}${char}"

    # Print the top border
    printf "%s\n" "${border_char}$(printf "%${grid_size}s" | tr ' ' "${border_char}")"

    # Print the character rows
    for ((i = 0; i < grid_size; i++)); do
        printf "%s" "$side_border"  # Left border
        for ((j = 0; j < grid_size; j++)); do
            printf "%s" "$repeated_char"  # Print the repeated character
        done
        printf "%s\n" "$side_border"  # Right border
    done

    # Print the bottom border
    printf "%s\n" "${border_char}$(printf "%${grid_size}s" | tr ' ' "${border_char}")"
}

# Main script execution
# Define the character set: A-Z, a-z, 0-9
chars=(
    {A..Z} {a..z} {0..9}
)

# Loop through each character and create a bordered grid
for char in "${chars[@]}"; do
    create_character_grid "$char"
    echo  # Add a blank line between grids
done