#!/bin/bash

# Check if the number of times to run the script is provided
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <script_to_run> <number_of_times>"
    exit 1
fi

script_to_run="$1"
n_times="$2"

# Loop to run the script n times
for ((i = 1; i <= n_times; i++)); do
    echo "Run #$i:"
    ./"$script_to_run"  # Run the script
done